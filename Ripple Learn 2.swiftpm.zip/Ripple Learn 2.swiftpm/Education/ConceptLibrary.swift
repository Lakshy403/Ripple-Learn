import Foundation

// ─────────────────────────────────────────────────────────────────────────────
// ConceptLibrary.swift
// ─────────────────────────────────────────────────────────────────────────────

struct Concept {
    let id: String
    let title: String
    let description: String
    let detailedExplanation: String
    let realWorldExample: String
}

class ConceptLibrary {
    @MainActor static let shared = ConceptLibrary()
    private init() {}

    static let wavePropagation = Concept(
        id: "wave_propagation",
        title: "Wave Propagation",
        description: "Waves spread outward in all directions from their source.",
        detailedExplanation: "When you tap the water, you create a disturbance. This disturbance travels outward in expanding circles, just like ripples on a pond.\n\nKey Properties:\n• Waves travel at a constant speed\n• Energy spreads in all directions\n• Amplitude decreases with distance",
        realWorldExample: "Dropping a pebble in water creates circular ripples that spread outward."
    )

    static let reflection = Concept(
        id: "reflection",
        title: "Reflection",
        description: "Waves bounce off surfaces at predictable angles.",
        detailedExplanation: "When waves hit a boundary (like a wall), they reflect back. The angle at which the wave hits equals the angle at which it bounces back.\n\nLaw of Reflection:\n• Angle of incidence = Angle of reflection\n• Works just like light bouncing off a mirror\n• Energy is preserved (mostly)",
        realWorldExample: "Echo is sound reflection. Light reflecting off mirrors. Ocean waves bouncing off cliffs."
    )

    static let interference = Concept(
        id: "interference",
        title: "Interference",
        description: "Multiple waves combine to create new patterns.",
        detailedExplanation: "When two or more waves meet, they combine their effects:\n\nConstructive Interference:\n• Wave peaks align → BIGGER wave\n• Amplitudes add together\n\nDestructive Interference:\n• Peak meets trough → waves CANCEL\n• Can result in calm water",
        realWorldExample: "Noise-canceling headphones use destructive interference. Musical chords use constructive interference."
    )

    static let refraction = Concept(
        id: "refraction",
        title: "Refraction",
        description: "Waves bend when entering different media.",
        detailedExplanation: "Wave speed changes in different materials or depths:\n\nDeep water → Fast waves\nShallow water → Slow waves\n\nWhen waves cross the boundary:\n• They bend (change direction)\n• Wavelength changes\n• Frequency stays the same",
        realWorldExample: "A straw appears bent in water. Ocean waves turn parallel to shore. Eyeglasses focus light."
    )

    static let resonance = Concept(
        id: "resonance",
        title: "Resonance",
        description: "Waves can build up when timing matches natural frequencies.",
        detailedExplanation: "Objects and spaces have natural frequencies — they 'prefer' to vibrate at certain rates.\n\nWhen you push at just the right rhythm:\n• Waves build upon themselves\n• Amplitude grows with each push\n• Can create very powerful effects",
        realWorldExample: "Pushing a swing at the right time. Musical instruments produce specific notes. Opera singer breaking glass."
    )

    static let complexSystems = Concept(
        id: "complex_systems",
        title: "Complex Systems",
        description: "Real-world physics combines all these principles.",
        detailedExplanation: "Real fluid dynamics involves all concepts working together:\n\n• Waves propagate\n• Reflect off boundaries\n• Interfere with each other\n• Refract through different media\n• Resonate in enclosed spaces",
        realWorldExample: "Ocean waves, weather patterns, sound in concert halls, water engineering."
    )

    func getConcept(for physicsConcept: PhysicsConcept) -> Concept {
        switch physicsConcept {
        case .wavePropagation: return ConceptLibrary.wavePropagation
        case .reflection:      return ConceptLibrary.reflection
        case .interference:    return ConceptLibrary.interference
        case .refraction:      return ConceptLibrary.refraction
        case .resonance:       return ConceptLibrary.resonance
        case .complexSystems:  return ConceptLibrary.complexSystems
        }
    }

    func getAllConcepts() -> [Concept] {
        [ConceptLibrary.wavePropagation, ConceptLibrary.reflection,
         ConceptLibrary.interference, ConceptLibrary.refraction,
         ConceptLibrary.resonance, ConceptLibrary.complexSystems]
    }
}
