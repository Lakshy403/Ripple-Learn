// PhysicsConcept.swift
// Canonical source of truth for all physics concepts in the Ripple game.
// No duplicate extensions needed anywhere — import this file and you're done.

import Foundation
import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - PhysicsConcept
// ─────────────────────────────────────────────────────────────────────────────

enum PhysicsConcept: String, CaseIterable, Identifiable, Codable {
    case wavePropagation = "Wave Propagation"
    case reflection      = "Reflection"
    case interference    = "Interference"
    case refraction      = "Refraction"
    case resonance       = "Resonance"
    case complexSystems  = "Complex Systems"

    var id: String { rawValue }

    // ── Numeric ID (used in Metal buffer packing) ─────────────────────────
    var intId: Int {
        switch self {
        case .wavePropagation: return 0
        case .reflection:      return 1
        case .interference:    return 2
        case .refraction:      return 3
        case .resonance:       return 4
        case .complexSystems:  return 5
        }
    }

    // ── SwiftUI accent colour ─────────────────────────────────────────────
    var accentColor: Color {
        switch self {
        case .wavePropagation: return Color(red: 0.10, green: 0.72, blue: 1.00)
        case .reflection:      return Color(red: 0.65, green: 0.78, blue: 1.00)
        case .interference:    return Color(red: 0.55, green: 0.28, blue: 1.00)
        case .refraction:      return Color(red: 0.15, green: 0.90, blue: 0.75)
        case .resonance:       return Color(red: 1.00, green: 0.55, blue: 0.22)
        case .complexSystems:  return Color(red: 1.00, green: 0.25, blue: 0.72)
        }
    }

    var secondaryColor: Color {
        switch self {
        case .wavePropagation: return Color(red: 0.00, green: 0.42, blue: 0.80)
        case .reflection:      return Color(red: 0.35, green: 0.55, blue: 0.95)
        case .interference:    return Color(red: 0.30, green: 0.05, blue: 0.65)
        case .refraction:      return Color(red: 0.00, green: 0.60, blue: 0.50)
        case .resonance:       return Color(red: 0.80, green: 0.30, blue: 0.05)
        case .complexSystems:  return Color(red: 0.70, green: 0.05, blue: 0.45)
        }
    }

    // ── SF Symbol icon ────────────────────────────────────────────────────
    var icon: String {
        switch self {
        case .wavePropagation: return "water.waves"
        case .reflection:      return "arrow.triangle.2.circlepath"
        case .interference:    return "waveform.path.ecg"
        case .refraction:      return "sunrise.fill"
        case .resonance:       return "waveform"
        case .complexSystems:  return "tornado"
        }
    }

    var emoji: String {
        switch self {
        case .wavePropagation: return "🌊"
        case .reflection:      return "🪞"
        case .interference:    return "🌀"
        case .refraction:      return "🌈"
        case .resonance:       return "🔊"
        case .complexSystems:  return "🌪️"
        }
    }

    var shortName: String {
        switch self {
        case .wavePropagation: return "Wave Basics"
        case .reflection:      return "Reflection"
        case .interference:    return "Interference"
        case .refraction:      return "Refraction"
        case .resonance:       return "Resonance"
        case .complexSystems:  return "Complex Systems"
        }
    }

    // ── Metal shader choppiness tuning ────────────────────────────────────
    var metalChoppiness: Float {
        switch self {
        case .wavePropagation: return 0.65
        case .reflection:      return 0.55
        case .interference:    return 0.90
        case .refraction:      return 0.60
        case .resonance:       return 1.10
        case .complexSystems:  return 1.30
        }
    }

    // ── SKShader tint (SpriteKit water shader) ────────────────────────────
    var skTint: SIMD3<Float> {
        switch self {
        case .wavePropagation: return SIMD3(0.00, 0.50, 0.90)
        case .reflection:      return SIMD3(0.60, 0.70, 1.00)
        case .interference:    return SIMD3(0.45, 0.20, 0.90)
        case .refraction:      return SIMD3(0.10, 0.85, 0.75)
        case .resonance:       return SIMD3(1.00, 0.55, 0.20)
        case .complexSystems:  return SIMD3(0.90, 0.20, 0.70)
        }
    }

    // ── iOS 18 MeshGradient colours ───────────────────────────────────────
    var meshColors: [Color] {
        let bg  = Color(red: 0.01, green: 0.04, blue: 0.10)
        let mid = Color(red: 0.02, green: 0.10, blue: 0.22)
        let acc = accentColor
        let sec = secondaryColor
        switch self {
        case .wavePropagation:
            return [bg, acc.opacity(0.6), bg,
                    mid, acc.opacity(0.4), sec.opacity(0.5),
                    bg,  sec.opacity(0.3), bg]
        case .reflection:
            return [bg, acc.opacity(0.5), acc.opacity(0.3),
                    mid, sec.opacity(0.4), acc.opacity(0.5),
                    bg,  acc.opacity(0.2), bg]
        case .interference:
            return [acc.opacity(0.4), bg, sec.opacity(0.4),
                    bg, mid, bg,
                    sec.opacity(0.3), bg, acc.opacity(0.3)]
        case .refraction:
            return [bg, acc.opacity(0.4), bg,
                    sec.opacity(0.3), mid, acc.opacity(0.5),
                    bg,  sec.opacity(0.4), bg]
        case .resonance:
            return [bg, bg, bg,
                    acc.opacity(0.3), mid, acc.opacity(0.5),
                    bg,  sec.opacity(0.6), bg]
        case .complexSystems:
            return [acc.opacity(0.3), sec.opacity(0.3), acc.opacity(0.3),
                    sec.opacity(0.2), mid, sec.opacity(0.2),
                    acc.opacity(0.3), sec.opacity(0.3), acc.opacity(0.3)]
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - ConceptMeshBackground  (iOS 18 animated mesh gradient)
// ─────────────────────────────────────────────────────────────────────────────

struct ConceptMeshBackground: View {
    let concept: PhysicsConcept
    @State private var animating = false

    var body: some View {
        if #available(iOS 18.0, *) {
            MeshGradient(
                width:  3, height: 3,
                points: animatedPoints,
                colors: concept.meshColors
            )
            .onAppear {
                withAnimation(.easeInOut(duration: 6).repeatForever(autoreverses: true)) {
                    animating = true
                }
            }
        } else {
            LinearGradient(
                colors: [
                    Color(red: 0.02, green: 0.06, blue: 0.12),
                    concept.accentColor.opacity(0.30)
                ],
                startPoint: .topLeading,
                endPoint:   .bottomTrailing
            )
        }
    }

    private var animatedPoints: [SIMD2<Float>] {
        let s = Float(animating ? 0.08 : -0.08)
        return [
            [0.0, 0.0], [0.5 + s * 0.3, 0.0], [1.0, 0.0],
            [0.0, 0.5], [0.5 + s * 0.5, 0.5 + s * 0.3], [1.0, 0.5],
            [0.0, 1.0], [0.5 - s * 0.3, 1.0],            [1.0, 1.0],
        ]
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - Notification names  (single source of truth)
// ─────────────────────────────────────────────────────────────────────────────

extension Notification.Name {
    static let gameConceptChanged  = Notification.Name("gameConceptChanged")
    static let gameLevelChanged    = Notification.Name("gameLevelChanged")
    static let gameRipplesChanged  = Notification.Name("gameRipplesChanged")
    static let levelComplete       = Notification.Name("levelComplete")
    static let handPointsUpdated   = Notification.Name("handPointsUpdated")
    static let gameStartConcept    = Notification.Name("gameStartConcept")
    static let metalTapForwarded   = Notification.Name("metalTapForwarded")
}
#Preview("Concept Mesh BG") {
    ConceptMeshBackground(concept: .wavePropagation)
}

