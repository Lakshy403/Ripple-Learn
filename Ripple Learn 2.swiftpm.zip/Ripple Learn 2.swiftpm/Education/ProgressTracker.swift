import Foundation

// ─────────────────────────────────────────────────────────────────────────────
// ProgressTracker.swift  —  Persistent player progress store
// ─────────────────────────────────────────────────────────────────────────────

struct LevelRecord: Codable {
    let level:      Int
    let timeSpent:  Double
    let concept:    String   // PhysicsConcept.rawValue
    let completedAt: Date
}

final class ProgressTracker {
    @MainActor static let shared = ProgressTracker()

    private let levelsKey       = "completedLevels"
    private let starsKey        = "levelStars"
    private let totalRipplesKey = "totalRipples"

    private(set) var completedLevels:  [Int]            = []
    private(set) var levelStars:       [Int: Int]       = [:]    // level → 1-3
    private(set) var levelRecords:     [LevelRecord]    = []
    private(set) var totalRipples:     Int              = 0

    // Concept-specific mastery (0–100)
    private var conceptScores: [String: Double] = [:]

    private init() { load() }

    // MARK: - Public API

    var highestLevel: Int { completedLevels.max() ?? 0 }

    var totalLevelsCompleted: Int { completedLevels.count }

    var overallMastery: Double {
        guard !conceptScores.isEmpty else { return 0 }
        return conceptScores.values.reduce(0, +) / Double(conceptScores.count)
    }

    func completeLevel(_ level: Int, time: Double, concept: PhysicsConcept) {
        if !completedLevels.contains(level) {
            completedLevels.append(level)
        }

        let stars = starsForTime(time, level: level)
        let existing = levelStars[level] ?? 0
        levelStars[level] = max(existing, stars)

        let record = LevelRecord(level: level, timeSpent: time,
                                 concept: concept.rawValue, completedAt: Date())
        levelRecords.append(record)
        if levelRecords.count > 200 { levelRecords.removeFirst() }

        updateConceptScore(for: concept, time: time)
        save()
    }

    func incrementRipples(by n: Int = 1) {
        totalRipples += n
        UserDefaults.standard.set(totalRipples, forKey: totalRipplesKey)
    }

    func masteryScore(for concept: PhysicsConcept) -> Double {
        conceptScores[concept.rawValue] ?? 0
    }

    func stars(for level: Int) -> Int {
        levelStars[level] ?? 0
    }

    func averageTime(for concept: PhysicsConcept) -> Double? {
        let relevant = levelRecords.filter { $0.concept == concept.rawValue }
        guard !relevant.isEmpty else { return nil }
        return relevant.map { $0.timeSpent }.reduce(0, +) / Double(relevant.count)
    }

    func recentActivity(limit: Int = 5) -> [LevelRecord] {
        Array(levelRecords.suffix(limit).reversed())
    }

    // MARK: - Private helpers

    private func starsForTime(_ time: Double, level: Int) -> Int {
        let threshold = 30.0 + Double(level) * 2.0
        if time < threshold * 0.5  { return 3 }
        if time < threshold        { return 2 }
        return 1
    }

    private func updateConceptScore(for concept: PhysicsConcept, time: Double) {
        let key   = concept.rawValue
        let old   = conceptScores[key] ?? 0
        let delta = max(0, 20.0 - time / 5.0)          // faster → more points
        conceptScores[key] = min(100, old + delta * 0.3)
    }

    // MARK: - Persistence

    private func save() {
        UserDefaults.standard.set(completedLevels, forKey: levelsKey)
        let starsData = levelStars.reduce(into: [String: Int]()) { $0["\($1.key)"] = $1.value }
        UserDefaults.standard.set(starsData, forKey: starsKey)
        if let data = try? JSONEncoder().encode(levelRecords) {
            UserDefaults.standard.set(data, forKey: "levelRecords")
        }
        if let scoreData = try? JSONEncoder().encode(conceptScores) {
            UserDefaults.standard.set(scoreData, forKey: "conceptScores")
        }
    }

    private func load() {
        completedLevels = UserDefaults.standard.array(forKey: levelsKey) as? [Int] ?? []
        let starsData   = UserDefaults.standard.dictionary(forKey: starsKey) as? [String: Int] ?? [:]
        levelStars = starsData.reduce(into: [Int: Int]()) {
            if let k = Int($1.key) { $0[k] = $1.value }
        }
        if let data = UserDefaults.standard.data(forKey: "levelRecords"),
           let records = try? JSONDecoder().decode([LevelRecord].self, from: data) {
            levelRecords = records
        }
        if let data = UserDefaults.standard.data(forKey: "conceptScores"),
           let scores = try? JSONDecoder().decode([String: Double].self, from: data) {
            conceptScores = scores
        }
        totalRipples = UserDefaults.standard.integer(forKey: totalRipplesKey)
    }
}
