import SpriteKit

class Flower: SKNode {
    private var velocity = CGVector.zero
    private var coreNode: SKShapeNode!

    init(position startPos: CGPoint) {
        super.init()
        self.position  = startPos
        self.zPosition = 10
        buildFlower()
        startIdleAnimation()
    }
    required init?(coder aDecoder: NSCoder) { fatalError() }

    private func buildFlower() {
        let halo = SKShapeNode(circleOfRadius: 40)
        halo.fillColor   = SKColor(red: 0.55, green: 0.88, blue: 1.00, alpha: 0.07)
        halo.strokeColor = .clear
        halo.glowWidth   = 30
        halo.zPosition   = -1
        addChild(halo)

        addPetalLayer(count: 8, length: 26, width: 11, distance: 20, baseAngle: 0,
            fill: SKColor(red: 0.82, green: 0.94, blue: 1.00, alpha: 0.50),
            stroke: SKColor(red: 0.70, green: 0.90, blue: 1.00, alpha: 0.65), zPos: 1)
        addPetalLayer(count: 8, length: 20, width: 9, distance: 14, baseAngle: .pi / 8,
            fill: SKColor(red: 0.90, green: 0.97, blue: 1.00, alpha: 0.62),
            stroke: SKColor(red: 0.80, green: 0.93, blue: 1.00, alpha: 0.72), zPos: 2)
        addPetalLayer(count: 6, length: 13, width: 6, distance: 8, baseAngle: .pi / 12,
            fill: SKColor(red: 0.95, green: 0.98, blue: 1.00, alpha: 0.78),
            stroke: SKColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 0.88), zPos: 3)

        let core = SKShapeNode(circleOfRadius: 7)
        core.fillColor   = SKColor(red: 1.00, green: 0.98, blue: 0.92, alpha: 1.00)
        core.strokeColor = SKColor(red: 1.00, green: 1.00, blue: 1.00, alpha: 1.00)
        core.lineWidth   = 1.5
        core.glowWidth   = 20
        core.zPosition   = 5
        addChild(core)
        coreNode = core

        let dot = SKShapeNode(circleOfRadius: 3)
        dot.fillColor   = SKColor(white: 1.0, alpha: 1.0)
        dot.strokeColor = .clear
        dot.glowWidth   = 10
        dot.zPosition   = 6
        addChild(dot)

        let shimmer = SKShapeNode()
        shimmer.path        = CGPath(ellipseIn: CGRect(x: -18, y: -4, width: 36, height: 5), transform: nil)
        shimmer.fillColor   = SKColor(red: 0.60, green: 0.88, blue: 1.00, alpha: 0.18)
        shimmer.strokeColor = .clear
        shimmer.zPosition   = -2
        shimmer.position    = CGPoint(x: 0, y: -26)
        addChild(shimmer)
    }

    private func addPetalLayer(count: Int, length: CGFloat, width: CGFloat, distance: CGFloat,
                                baseAngle: CGFloat, fill: SKColor, stroke: SKColor, zPos: CGFloat) {
        for i in 0..<count {
            let angle = baseAngle + CGFloat(i) * (.pi * 2 / CGFloat(count))
            let path = CGMutablePath()
            path.move(to: .zero)
            path.addCurve(to: CGPoint(x: 0, y: length),
                          control1: CGPoint(x:  width, y: length * 0.38),
                          control2: CGPoint(x:  width, y: length * 0.78))
            path.addCurve(to: .zero,
                          control1: CGPoint(x: -width, y: length * 0.78),
                          control2: CGPoint(x: -width, y: length * 0.38))
            path.closeSubpath()

            let petal = SKShapeNode(path: path)
            petal.fillColor   = fill
            petal.strokeColor = stroke
            petal.lineWidth   = 0.8
            petal.glowWidth   = 4
            petal.zPosition   = zPos

            let dx = cos(angle - .pi / 2) * distance
            let dy = sin(angle - .pi / 2) * distance
            petal.position  = CGPoint(x: dx, y: dy)
            petal.zRotation = angle
            addChild(petal)
        }
    }

    private func startIdleAnimation() {
        let out = SKAction.scale(to: 1.06, duration: 1.8)
        let inn = SKAction.scale(to: 0.94, duration: 1.8)
        out.timingMode = .easeInEaseOut
        inn.timingMode = .easeInEaseOut
        run(SKAction.repeatForever(SKAction.sequence([out, inn])))
        coreNode.run(SKAction.repeatForever(
            SKAction.customAction(withDuration: 1.2) { [weak self] _, t in
                self?.coreNode?.glowWidth = 18 + sin(t / 1.2 * .pi) * 14
            }
        ))
        run(SKAction.repeatForever(SKAction.rotate(byAngle: .pi * 2, duration: 22)))
    }

    func flashImpact() {
        coreNode?.run(SKAction.sequence([
            SKAction.colorize(with: .white, colorBlendFactor: 0.7, duration: 0.05),
            SKAction.colorize(withColorBlendFactor: 0.0, duration: 0.22)
        ]))
        run(SKAction.sequence([
            SKAction.scale(to: 1.28, duration: 0.08),
            SKAction.scale(to: 1.00, duration: 0.22)
        ]))
    }

    func applyForce(_ force: CGVector) {
        velocity.dx += force.dx
        velocity.dy += force.dy
        if hypot(force.dx, force.dy) > 1.5 { flashImpact() }
    }

    func update() {
        position.x += velocity.dx
        position.y += velocity.dy
        velocity.dx *= 0.95
        velocity.dy *= 0.95
    }

    func getVelocity() -> CGVector { velocity }
    func setVelocity(_ v: CGVector) { velocity = v }
}
