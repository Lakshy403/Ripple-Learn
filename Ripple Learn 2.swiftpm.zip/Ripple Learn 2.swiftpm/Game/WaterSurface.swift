// WaterSurface.swift
// SpriteKit water surface node — owns the SKShader caustic background,
// concept-specific environment overlays, and spawns physics Ripple nodes.
//
// Metal GPU rings are handled by WaterRippleView in the SwiftUI layer above;
// this node handles the simulation / force-application layer only.

import SpriteKit

class WaterSurface: SKNode {

    // ── Public API ────────────────────────────────────────────────────────
    private(set) var ripples:         [Ripple]      = []
    private(set) var reflectionWalls: [SKShapeNode] = []

    // ── Internal state ────────────────────────────────────────────────────
    private var currentConcept:   PhysicsConcept = .wavePropagation
    private var environmentNodes: [SKNode]       = []
    private var waterShader:      SKShader?
    private var shaderSprite:     SKSpriteNode?
    private var gpuReady = false

    // ─────────────────────────────────────────────────────────────────────
    override init() {
        super.init()
        createWaterBackground()
        createGlassEffect()
    }
    required init?(coder aDecoder: NSCoder) { fatalError() }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Lifecycle
    // ─────────────────────────────────────────────────────────────────────

    /// Call once after the node has been added to an SKScene.
    func didEnterScene() {
        guard !gpuReady else { return }
        gpuReady = true
        buildWaterShader()
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Background layers
    // ─────────────────────────────────────────────────────────────────────

    private func createWaterBackground() {
        let sz = CGSize(width: 2000, height: 2000)

        // Solid deep-ocean base
        let base = SKShapeNode(rectOf: sz)
        base.fillColor   = SKColor(red: 0.02, green: 0.14, blue: 0.28, alpha: 1.0)
        base.strokeColor = .clear
        base.zPosition   = -20
        addChild(base)

        // Parallax colour layers
        let fills: [(r: CGFloat, g: CGFloat, b: CGFloat, a: CGFloat)] = [
            (0.04, 0.28, 0.52, 0.55),
            (0.06, 0.36, 0.62, 0.45),
            (0.10, 0.45, 0.72, 0.35),
            (0.20, 0.58, 0.82, 0.25),
        ]
        let vAmps: [CGFloat] = [22, 18, 14, 10]
        let hAmps: [CGFloat] = [14, 10,  8,  6]
        let vDurs: [Double]  = [2.20, 2.75, 3.30, 3.85]
        let hDurs: [Double]  = [3.10, 3.45, 3.80, 4.15]

        for (i, c) in fills.enumerated() {
            let layer = SKShapeNode(rectOf: sz)
            layer.fillColor   = SKColor(red: c.r, green: c.g, blue: c.b, alpha: c.a)
            layer.strokeColor = .clear
            layer.zPosition   = CGFloat(-15 + i)
            addChild(layer)

            let ay = vAmps[i], ax = hAmps[i]
            let vd = vDurs[i], hd = hDurs[i]
            layer.run(SKAction.repeatForever(SKAction.group([
                SKAction.repeatForever(SKAction.sequence([
                    SKAction.moveBy(x: 0, y:  ay, duration: vd),
                    SKAction.moveBy(x: 0, y: -ay, duration: vd),
                ])),
                SKAction.repeatForever(SKAction.sequence([
                    SKAction.moveBy(x:  ax, y: 0, duration: hd),
                    SKAction.moveBy(x: -ax, y: 0, duration: hd),
                ])),
            ])))
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - SKShader (GLSL caustic + Gerstner background)
    // ─────────────────────────────────────────────────────────────────────

    private func buildWaterShader() {
        let size   = CGSize(width: 2000, height: 2000)
        let sprite = SKSpriteNode(color: .clear, size: size)
        sprite.zPosition = -8

        let source = """
        uniform float u_speed;
        uniform float u_intensity;
        uniform float u_scale;
        uniform vec3  u_tint;

        const float TAU  = 6.28318530718;
        const int   ITER = 4;

        vec2 rot(vec2 v, float a) {
            return vec2(cos(a)*v.x - sin(a)*v.y,
                        sin(a)*v.x + cos(a)*v.y);
        }

        float caustic(vec2 p, float t) {
            vec2 i = p; float c = 1.0;
            for (int n = 0; n < ITER; n++) {
                float it = 0.7 + float(n) * 0.11;
                i = p + vec2(cos(t - i.x*it) + sin(t + i.y*it),
                             sin(t - i.y*it) + cos(t + i.x*it));
                c += 1.0 / length(p / (sin(i.x + t) * u_intensity + vec2(0.001)));
            }
            c /= float(ITER);
            c  = 1.17 - pow(c, 1.4);
            return pow(abs(c), 8.0);
        }

        float gerstner(vec2 uv, float t) {
            float h = 0.0;
            h += 0.018 * sin(dot(normalize(vec2( 0.7,  0.3)), uv) *  5.5 + t*1.2);
            h += 0.012 * sin(dot(normalize(vec2(-0.4,  0.8)), uv) *  7.0 + t*0.9);
            h += 0.007 * sin(dot(normalize(vec2( 0.2, -0.6)), uv) * 12.0 + t*1.6);
            h += 0.004 * sin(dot(normalize(vec2(-0.9,  0.1)), uv) * 20.0 + t*2.3);
            return h;
        }

        void main() {
            vec2  uv = v_tex_coord; uv.y = 1.0 - uv.y;
            float t  = u_time * u_speed;
            vec2  p  = mod(uv * TAU * u_scale,           TAU) - 250.0;
            vec2  p2 = mod(uv * TAU * u_scale * 0.7
                         + vec2(2.3, 1.1),                TAU) - 250.0;
            float c  = mix(caustic(p, t),
                           caustic(rot(p2, 0.4), t*0.85 + 1.5), 0.5);
            float s  = clamp(gerstner(uv * 12.0, t) * 8.0, 0.0, 1.0);
            vec3  base = mix(vec3(0.01, 0.07, 0.14), u_tint * 0.4, 0.20);
            base += vec3(0.35, 0.82, 1.0) * c * 0.40;
            base += vec3(0.75, 0.92, 1.0) * s * 0.20;
            base  = clamp(base, 0.0, 1.0);
            vec2 vig = uv * 2.0 - 1.0;
            base    *= 1.0 - dot(vig, vig) * 0.22;
            gl_FragColor = vec4(base, 0.55);
        }
        """

        let tint = vector_float3(0.0, 0.5, 0.9)
        waterShader = SKShader(source: source, uniforms: [
            SKUniform(name: "u_speed",     float: 0.32),
            SKUniform(name: "u_intensity", float: 0.004),
            SKUniform(name: "u_scale",     float: 1.8),
            SKUniform(name: "u_tint",      vectorFloat3: tint),
        ])
        sprite.shader = waterShader
        shaderSprite  = sprite
        addChild(sprite)
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Glass sheen overlay
    // ─────────────────────────────────────────────────────────────────────

    private func createGlassEffect() {
        let glass = SKShapeNode(rectOf: CGSize(width: 2000, height: 2000))
        glass.fillColor   = SKColor(red: 0.75, green: 0.92, blue: 1.0, alpha: 0.07)
        glass.strokeColor = .clear
        glass.zPosition   = -5
        addChild(glass)
        glass.run(SKAction.repeatForever(SKAction.sequence([
            SKAction.fadeAlpha(to: 0.04, duration: 2.2),
            SKAction.fadeAlpha(to: 0.11, duration: 2.2),
        ])))

        for i in 0..<3 {
            let ref = SKShapeNode(rectOf: CGSize(width: 180, height: 70))
            ref.fillColor   = SKColor(white: 1.0, alpha: 0.08)
            ref.strokeColor = .clear
            ref.zPosition   = -4
            let sx: CGFloat = -500 + CGFloat(i) * 400
            let sy: CGFloat = -300 + CGFloat(i) * 200
            ref.position    = CGPoint(x: sx, y: sy)
            ref.zRotation   = .pi / 6 + CGFloat(i) * 0.3
            addChild(ref)
            ref.run(SKAction.repeatForever(SKAction.sequence([
                SKAction.moveBy(x: 1000, y: 300, duration: 18.0 + Double(i) * 4),
                SKAction.run { ref.position = CGPoint(x: sx, y: sy) },
            ])))
            ref.run(SKAction.repeatForever(SKAction.sequence([
                SKAction.fadeAlpha(to: 0.12, duration: 3.0),
                SKAction.fadeAlpha(to: 0.03, duration: 3.0),
            ])))
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Concept environment setup
    // ─────────────────────────────────────────────────────────────────────

    func setupConceptEnvironment(concept: PhysicsConcept, boundaryRect: CGRect) {
        environmentNodes.forEach { $0.removeFromParent() }
        environmentNodes.removeAll()
        reflectionWalls.removeAll()
        currentConcept = concept
        updateShaderTint(for: concept)

        switch concept {
        case .wavePropagation:
            break   // clean slate — Metal shader handles all visuals
        case .reflection:
            createReflectionWalls(in: boundaryRect)
        case .interference:
            createInterferenceGrid(in: boundaryRect)
        case .refraction:
            createRefractionZones(in: boundaryRect)
        case .resonance:
            createResonanceIndicators(in: boundaryRect)
        case .complexSystems:
            createReflectionWalls(in: boundaryRect)
            createRefractionZones(in: boundaryRect)
        }
    }

    private func updateShaderTint(for concept: PhysicsConcept) {
        let t = concept.skTint
        waterShader?.uniformNamed("u_tint")?.vectorFloat3Value =
            vector_float3(t.x, t.y, t.z)
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Environment builders
    // ─────────────────────────────────────────────────────────────────────

    private func createReflectionWalls(in rect: CGRect) {
        for i in 0..<2 {
            let len: CGFloat = rect.height * 0.5
            let x = rect.minX + rect.width * (0.35 + CGFloat(i) * 0.30)
            let sy = rect.minY + (rect.height - len) / 2
            let ey = sy + len

            // Main wall
            let wall = SKShapeNode()
            let wp   = CGMutablePath()
            wp.move(to: CGPoint(x: x, y: sy))
            wp.addLine(to: CGPoint(x: x, y: ey))
            wall.path        = wp
            wall.strokeColor = SKColor(red: 0.70, green: 0.80, blue: 0.90, alpha: 0.70)
            wall.lineWidth   = 8
            wall.glowWidth   = 15
            wall.zPosition   = 2

            // Inner sheen
            let refl = SKShapeNode()
            let rp   = CGMutablePath()
            rp.move(to: CGPoint(x: x + 3, y: sy))
            rp.addLine(to: CGPoint(x: x + 3, y: ey))
            refl.path        = rp
            refl.strokeColor = SKColor(red: 0.90, green: 0.95, blue: 1.00, alpha: 0.30)
            refl.lineWidth   = 3
            refl.zPosition   = 3

            [wall, refl].forEach { addChild($0) }
            environmentNodes += [wall, refl]
            reflectionWalls.append(wall)
        }
    }

    private func createInterferenceGrid(in rect: CGRect) {
        let grid = SKShapeNode()
        let path = CGMutablePath()
        let step: CGFloat = 80

        var x = rect.minX
        while x <= rect.maxX {
            path.move(to: CGPoint(x: x, y: rect.minY))
            path.addLine(to: CGPoint(x: x, y: rect.maxY))
            x += step
        }
        var y = rect.minY
        while y <= rect.maxY {
            path.move(to: CGPoint(x: rect.minX, y: y))
            path.addLine(to: CGPoint(x: rect.maxX, y: y))
            y += step
        }

        grid.path        = path
        grid.strokeColor = SKColor(red: 0.50, green: 0.70, blue: 0.90, alpha: 0.20)
        grid.lineWidth   = 1
        grid.zPosition   = 1
        grid.run(SKAction.repeatForever(SKAction.sequence([
            SKAction.fadeAlpha(to: 0.10, duration: 1.5),
            SKAction.fadeAlpha(to: 0.25, duration: 1.5),
        ])))
        addChild(grid)
        environmentNodes.append(grid)
    }

    private func createRefractionZones(in rect: CGRect) {
        let midY = (rect.minY + rect.maxY) / 2

        // Shallow zone (top half)
        let shallow = SKShapeNode(rect: CGRect(x: rect.minX, y: midY,
                                               width: rect.width, height: rect.height / 2))
        shallow.fillColor   = SKColor(red: 0.50, green: 0.80, blue: 0.95, alpha: 0.25)
        shallow.strokeColor = .clear
        shallow.zPosition   = 1
        addChild(shallow)
        environmentNodes.append(shallow)

        // Deep zone (bottom half)
        let deep = SKShapeNode(rect: CGRect(x: rect.minX, y: rect.minY,
                                             width: rect.width, height: rect.height / 2))
        deep.fillColor   = SKColor(red: 0.10, green: 0.40, blue: 0.70, alpha: 0.30)
        deep.strokeColor = .clear
        deep.zPosition   = 1
        addChild(deep)
        environmentNodes.append(deep)

        // Interface line
        let line = SKShapeNode()
        let lp   = CGMutablePath()
        lp.move(to: CGPoint(x: rect.minX, y: midY))
        lp.addLine(to: CGPoint(x: rect.maxX, y: midY))
        line.path        = lp
        line.strokeColor = SKColor(red: 0.70, green: 0.90, blue: 1.00, alpha: 0.60)
        line.lineWidth   = 2
        line.glowWidth   = 8
        line.zPosition   = 2
        line.run(SKAction.repeatForever(SKAction.sequence([
            SKAction.fadeAlpha(to: 0.40, duration: 1.2),
            SKAction.fadeAlpha(to: 0.80, duration: 1.2),
        ])))
        addChild(line)
        environmentNodes.append(line)

        // Labels
        for (text, yOff) in [("Shallow (Slow)", midY + 40.0), ("Deep (Fast)", midY - 60.0)] {
            let lbl         = SKLabelNode(text: text)
            lbl.fontSize    = 14
            lbl.fontName    = "AvenirNext-Medium"
            lbl.fontColor   = SKColor(red: 0.50, green: 0.80, blue: 0.95, alpha: 0.80)
            lbl.position    = CGPoint(x: 0, y: yOff)
            lbl.zPosition   = 3
            addChild(lbl)
            environmentNodes.append(lbl)
        }
    }

    private func createResonanceIndicators(in rect: CGRect) {
        let baseY = (rect.minY + rect.maxY) / 2
        for i in 0..<3 {
            let radius: CGFloat = 60 + CGFloat(i) * 30
            let x = rect.minX + rect.width * (0.25 + CGFloat(i) * 0.25)
            let pos = CGPoint(x: x, y: baseY)

            let zone = SKShapeNode(circleOfRadius: radius)
            zone.strokeColor = SKColor(red: 1.0, green: 0.6, blue: 0.3, alpha: 0.40)
            zone.fillColor   = .clear
            zone.lineWidth   = 2
            zone.position    = pos
            zone.zPosition   = 1
            zone.run(SKAction.repeatForever(SKAction.sequence([
                SKAction.scale(to: 1.15, duration: 1.2),
                SKAction.scale(to: 0.85, duration: 1.2),
            ])))

            let glow = SKShapeNode(circleOfRadius: radius * 0.9)
            glow.strokeColor = SKColor(red: 1.0, green: 0.8, blue: 0.5, alpha: 0.20)
            glow.fillColor   = .clear
            glow.lineWidth   = 1
            glow.position    = pos
            glow.zPosition   = 1
            glow.run(SKAction.repeatForever(SKAction.sequence([
                SKAction.fadeAlpha(to: 0.60, duration: 1.2),
                SKAction.fadeAlpha(to: 0.20, duration: 1.2),
            ])))

            [zone, glow].forEach { addChild($0) }
            environmentNodes += [zone, glow]
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Ripple spawning
    // ─────────────────────────────────────────────────────────────────────

    /// Spawn a SpriteKit Ripple node (handles physics force propagation).
    /// The Metal ring visuals are rendered by WaterRippleView above.
    @discardableResult
    func spawnRipple(at position: CGPoint,
                     concept:    PhysicsConcept = .wavePropagation,
                     intensity:  CGFloat        = 1.0) -> Ripple {
        let r       = Ripple(concept: concept, intensity: intensity)
        r.position  = position
        addChild(r)
        r.animate()
        ripples.append(r)
        ripples.removeAll { $0.parent == nil }   // trim dead nodes
        return r
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Accessors
    // ─────────────────────────────────────────────────────────────────────

    func getRipples()         -> [Ripple]      { ripples.filter { $0.parent != nil } }
    func getReflectionWalls() -> [SKShapeNode] { reflectionWalls }
}
