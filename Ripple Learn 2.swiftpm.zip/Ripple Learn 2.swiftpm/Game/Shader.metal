//  Shaders.metal
//  GPU-accelerated interactive water ripple system
//  Uses Gerstner waves + caustic light simulation + touch-driven ripple distortion
//
//  Architecture:
//    rippleDistortion  – main fragment shader (texture warp + caustics + foam)
//    waterNormal       – builds a normal map from height-field sum
//    compositeWater    – final PBR-lite composite (reflection + refraction + fresnel)

#include <metal_stdlib>
#include <SwiftUI/SwiftUI.h>   // for [[stitchable]], half4, float2 etc.
using namespace metal;

// ─────────────────────────────────────────────────────────────────────────────
// Shared constants & helpers
// ─────────────────────────────────────────────────────────────────────────────

constant float TAU  = 6.28318530718;
constant float PI   = 3.14159265359;
constant int   WAVE_COUNT    = 8;    // Gerstner wave harmonics
constant int   RIPPLE_MAX    = 16;   // max simultaneous touch ripples
constant int   CAUSTIC_ITER  = 5;    // caustic refinement iterations

// Smooth hash
float2 hash2(float2 p) {
    p = float2(dot(p, float2(127.1, 311.7)),
               dot(p, float2(269.5, 183.3)));
    return fract(sin(p) * 43758.5453123);
}

float hash1(float2 p) {
    return fract(sin(dot(p, float2(127.1, 311.7))) * 43758.5453123);
}

// Smooth noise
float noise(float2 p) {
    float2 i = floor(p);
    float2 f = fract(p);
    float2 u = f * f * (3.0 - 2.0 * f);

    float a = hash1(i + float2(0,0));
    float b = hash1(i + float2(1,0));
    float c = hash1(i + float2(0,1));
    float d = hash1(i + float2(1,1));

    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Fractional Brownian Motion — layered noise for organic water surface
float fbm(float2 p, int octaves) {
    float v = 0.0, a = 0.5;
    float2x2 rot = float2x2(0.8, -0.6, 0.6, 0.8);
    for (int i = 0; i < octaves; i++) {
        v += a * noise(p);
        p  = rot * p * 2.1;
        a *= 0.5;
    }
    return v;
}

// Gerstner wave — physically-based ocean wave model
//   A  = amplitude, k = wave-number direction, w = angular freq, phi = phase
float3 gerstner(float2 pos, float2 k, float A, float w, float phi, float time) {
    float2 kn   = normalize(k);
    float  km   = length(k);
    float  theta = dot(kn * km, pos) - w * time + phi;
    float  c     = cos(theta);
    float  s     = sin(theta);
    // horizontal displacement (xy) + vertical (z)
    return float3(kn * (A * c), A * s);
}

// Sum of N Gerstner waves → returns (dispX, dispY, height)
float3 oceanSurface(float2 uv, float time, float choppiness) {
    // Pre-baked wave directions, amplitudes, frequencies (tuned for visual quality)
    const float2 dirs[8]  = { float2(1.0, 0.0), float2(0.7, 0.7),
                               float2(0.0, 1.0), float2(-0.5, 0.86),
                               float2(0.94, 0.34),float2(-0.77, 0.64),
                               float2(0.64, -0.77),float2(-0.34, 0.94) };
    const float  amps[8]  = { 0.028, 0.018, 0.014, 0.010, 0.007, 0.005, 0.004, 0.003 };
    const float  freqs[8] = { 1.2,   2.0,   3.1,   4.8,   7.5,  12.0,  18.0,  28.0  };
    const float  speeds[8]= { 1.0,   1.2,   1.4,   1.6,   1.8,   2.0,   2.2,   2.4  };

    float3 result = float3(0.0);
    for (int i = 0; i < WAVE_COUNT; i++) {
        float A  = amps[i];
        float km = freqs[i];
        float w  = speeds[i] * sqrt(9.81 * km);   // deep-water dispersion
        float phi= hash1(dirs[i]) * TAU;
        result  += gerstner(uv * 4.0, dirs[i], A * choppiness, w, phi, time);
    }
    return result;
}

// ─────────────────────────────────────────────────────────────────────────────
// Touch-ripple height contribution
//   rippleData: packed float4 per ripple (originX, originY, age, intensity)
// ─────────────────────────────────────────────────────────────────────────────
float touchRippleHeight(float2 uv, float2 aspect,
                        device const float4 *rippleData, int rippleCount,
                        float time) {
    float h = 0.0;
    for (int i = 0; i < rippleCount && i < RIPPLE_MAX; i++) {
        float2 origin    = rippleData[i].xy;        // normalised 0..1
        float  age       = rippleData[i].z;         // seconds since tap
        float  intensity = rippleData[i].w;

        if (age < 0.0) continue;   // inactive slot

        float2 delta = (uv - origin) * aspect;
        float  dist  = length(delta);

        float  speed       = 0.38;          // wave-front expansion rate (uv/sec)
        float  wavefront   = age * speed;
        float  wavelength  = 0.07;
        float  ringWidth   = 0.10 + age * 0.04;

        // Envelope: Gaussian around expanding wavefront
        float  envelope    = exp(-pow((dist - wavefront) / ringWidth, 2.0) * 6.0);
        float  decay       = exp(-age * 1.4);
        float  phase       = (dist - wavefront) / wavelength * TAU;
        float  wave        = cos(phase) * envelope * decay * intensity * 0.035;

        h += wave;
    }
    return h;
}

// ─────────────────────────────────────────────────────────────────────────────
// Caustic simulation — ray-traced light focusing through water surface
// ─────────────────────────────────────────────────────────────────────────────
float caustic(float2 uv, float time, float scale) {
    float2 p  = uv * scale;
    float2 i  = p;
    float  c  = 1.0;
    float  inten = 0.005;

    for (int n = 0; n < CAUSTIC_ITER; n++) {
        float t   = time * 0.4 * (1.0 - 3.5 / float(n + 1));
        float it  = 0.7 + float(n) * 0.15;
        i = p + float2(cos(t - i.x * it) + sin(t + i.y * it),
                       sin(t - i.y * it) + cos(t + i.x * it));
        c += 1.0 / length(p / (sin(i.x + t) * inten + float2(0.0001)));
    }
    c /= float(CAUSTIC_ITER);
    c  = 1.17 - pow(c, 1.4);
    return pow(abs(c), 8.0) * 2.2;
}

// ─────────────────────────────────────────────────────────────────────────────
// Fresnel approximation (Schlick)
// ─────────────────────────────────────────────────────────────────────────────
float fresnel(float3 normal, float3 viewDir, float F0) {
    float cosTheta = saturate(dot(normal, viewDir));
    return F0 + (1.0 - F0) * pow(1.0 - cosTheta, 5.0);
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN SHADER 1: rippleDistortion
//
//   Inputs:  pos        – fragment position in SwiftUI points
//            args       – float array:
//                           [0]  time
//                           [1]  choppiness  (0..1, default 0.6)
//                           [2]  rippleCount (int cast)
//                           [3]  aspectRatio (width/height)
//                           [4..4+rippleCount*4] = ripple data
// ─────────────────────────────────────────────────────────────────────────────
[[stitchable]]
half4 rippleDistortion(float2         pos,
                       SwiftUI::Layer layer,
                       float2         size,
                       float          time,
                       float          choppiness,
                       device   const float4 *ripples [[buffer(0)]],
                       int            rippleCount)
{
    float2 uv     = pos / size;
    float  aspect = size.x / size.y;
    float2 asp    = float2(aspect, 1.0);

    // 1 ── Ocean surface displacement ──────────────────────────────────────
    float3 ocean  = oceanSurface(uv, time, choppiness);
    float2 disp   = ocean.xy;        // horizontal Gerstner displacement
    float  height = ocean.z;         // vertical height

    // 2 ── Touch ripple displacement ───────────────────────────────────────
    float  ripH   = touchRippleHeight(uv, asp, ripples, rippleCount, time);
    // Convert scalar ripple height to 2D gradient (finite differences)
    float  eps    = 0.003;
    float  ripHdx = touchRippleHeight(uv + float2(eps, 0), asp, ripples, rippleCount, time);
    float  ripHdy = touchRippleHeight(uv + float2(0, eps), asp, ripples, rippleCount, time);
    float2 ripGrad = float2(ripH - ripHdx, ripH - ripHdy) / eps;

    // 3 ── FBM micro-ripple (wind chop) ───────────────────────────────────
    float2 micro  = float2(
        fbm(uv * 12.0 + float2(time * 0.15, time * 0.09), 4) - 0.5,
        fbm(uv * 12.0 + float2(time * 0.09, time * 0.15) + 3.7, 4) - 0.5
    ) * 0.008;

    // 4 ── Combine all displacements ───────────────────────────────────────
    float2 totalDisp = disp * 0.04 + ripGrad * 0.06 + micro;
    float2 warpedUV  = uv + totalDisp;
    warpedUV = clamp(warpedUV, float2(0.001), float2(0.999));

    // 5 ── Sample the layer (scene behind water) with warped UV ───────────
    half4  sceneColor = layer.sample(warpedUV * size);

    // 6 ── Surface normal from height field ───────────────────────────────
    float eps2  = 0.005;
    float hL    = oceanSurface(uv - float2(eps2, 0), time, choppiness).z;
    float hR    = oceanSurface(uv + float2(eps2, 0), time, choppiness).z;
    float hD    = oceanSurface(uv - float2(0, eps2), time, choppiness).z;
    float hU    = oceanSurface(uv + float2(0, eps2), time, choppiness).z;
    float3 N    = normalize(float3(hL - hR, hD - hU, eps2 * 2.0));

    // 7 ── Caustics ────────────────────────────────────────────────────────
    float  caus1 = caustic(uv + float2(time * 0.04, time * 0.03), time, 2.2);
    float  caus2 = caustic(uv - float2(time * 0.03, time * 0.04), time, 3.1) * 0.6;
    float  caus  = (caus1 + caus2) * 0.5;

    // 8 ── Water colour tint + depth ───────────────────────────────────────
    float  depth       = saturate(0.5 + height * 4.0);
    float3 shallowCol  = float3(0.04, 0.38, 0.58);
    float3 deepCol     = float3(0.01, 0.10, 0.22);
    float3 waterTint   = mix(deepCol, shallowCol, depth);

    // 9 ── Specular highlight (sun) ────────────────────────────────────────
    float3 lightDir    = normalize(float3(0.6, 1.0, 0.8));
    float3 viewDir     = float3(0.0, 0.0, 1.0);
    float3 halfVec     = normalize(lightDir + viewDir);
    float  spec        = pow(saturate(dot(N, halfVec)), 180.0) * 2.5;
    float3 specCol     = float3(1.0, 0.97, 0.90) * spec;

    // 10 ── Fresnel blend scene ↔ water surface ────────────────────────────
    float  fr          = fresnel(N, viewDir, 0.04);
    float3 scene3      = float3(sceneColor.r, sceneColor.g, sceneColor.b);

    // Refracted scene seen through water
    float3 refracted   = mix(scene3, scene3 * waterTint * 1.4, 0.55);
    // Add caustic light
    refracted         += float3(0.35, 0.82, 1.0) * caus * 0.28;

    // Surface reflection colour (sky / environment approximation)
    float3 skyCol      = mix(float3(0.01, 0.18, 0.44), float3(0.50, 0.82, 1.00),
                             saturate(N.y * 0.5 + 0.5));
    float3 reflected   = skyCol + specCol;

    // Fresnel composite
    float3 finalCol    = mix(refracted, reflected, fr * 0.72);

    // 11 ── Foam on crests ─────────────────────────────────────────────────
    float  foam        = smoothstep(0.028, 0.055, height) * 0.55;
    foam              += smoothstep(0.005, 0.015, abs(ripH)) * 0.35;   // ripple foam
    finalCol           = mix(finalCol, float3(0.88, 0.96, 1.00), foam);

    // 12 ── Edge vignette ──────────────────────────────────────────────────
    float2 vig         = uv * 2.0 - 1.0;
    float  vignette    = 1.0 - dot(vig, vig) * 0.18;
    finalCol          *= vignette;

    return half4(half3(finalCol), sceneColor.a);
}

// ─────────────────────────────────────────────────────────────────────────────
// SHADER 2: waterNormal
//   Outputs a normal-map texture for downstream PBR passes.
// ─────────────────────────────────────────────────────────────────────────────
[[stitchable]]
half4 waterNormal(float2        pos,
                  SwiftUI::Layer layer,
                  float2         size,
                  float          time,
                  float          choppiness)
{
    float2 uv  = pos / size;
    float  eps = 0.004;

    // Sample height at neighbours (Metal doesn't support lambdas)
    float hL = oceanSurface(uv - float2(eps, 0), time, choppiness).z
             + fbm((uv - float2(eps, 0)) * 10.0 + float2(time * 0.1), 3) * 0.012;
    float hR = oceanSurface(uv + float2(eps, 0), time, choppiness).z
             + fbm((uv + float2(eps, 0)) * 10.0 + float2(time * 0.1), 3) * 0.012;
    float hD = oceanSurface(uv - float2(0, eps), time, choppiness).z
             + fbm((uv - float2(0, eps)) * 10.0 + float2(time * 0.1), 3) * 0.012;
    float hU = oceanSurface(uv + float2(0, eps), time, choppiness).z
             + fbm((uv + float2(0, eps)) * 10.0 + float2(time * 0.1), 3) * 0.012;

    float3 N = normalize(float3(hL - hR, hD - hU, eps * 1.5));
    // Pack to 0..1
    return half4(half3(N * 0.5 + 0.5), 1.0);
}

// ─────────────────────────────────────────────────────────────────────────────
// SHADER 3: touchRippleOnly
//   Lightweight shader — just renders touch ripple rings over a clear layer.
//   Use this on top of a UIKit view for best performance.
// ─────────────────────────────────────────────────────────────────────────────
[[stitchable]]
half4 touchRippleOnly(float2         pos,
                      SwiftUI::Layer layer,
                      float2         size,
                      float          time,
                      device const float4 *ripples [[buffer(0)]],
                      int            rippleCount)
{
    float2 uv     = pos / size;
    float  aspect = size.x / size.y;
    float2 asp    = float2(aspect, 1.0);

    half4  base   = layer.sample(pos);
    float3 addCol = float3(0.0);
    float  addA   = 0.0;

    for (int i = 0; i < rippleCount && i < RIPPLE_MAX; i++) {
        float2 origin    = ripples[i].xy;
        float  age       = ripples[i].z;
        float  intensity = ripples[i].w;
        if (age < 0.0) continue;

        float2 delta   = (uv - origin) * asp;
        float  dist    = length(delta);
        float  speed   = 0.38;
        float  wf      = age * speed;
        float  decay   = exp(-age * 1.2);
        float  rw      = 0.008 + age * 0.002;     // ring thickness

        // Primary ring
        float  ring    = exp(-pow((dist - wf) / rw, 2.0) * 8.0) * decay * intensity;
        // Secondary echo ring (half amplitude)
        float  echo    = exp(-pow((dist - wf * 0.78) / (rw * 1.4), 2.0) * 6.0)
                         * decay * intensity * 0.4;

        // Colour: cyan core → white crest → faint teal fade
        float3 ringCol = mix(float3(0.10, 0.72, 1.00),
                             float3(0.85, 0.97, 1.00),
                             ring);
        ringCol       += float3(0.20, 0.90, 0.80) * echo;

        addCol += ringCol * (ring + echo);
        addA   += (ring + echo * 0.5);
    }

    addA = saturate(addA);
    float3 result = mix(float3(base.rgb), float3(base.rgb) + addCol, addA * 0.85);
    return half4(half3(result), base.a);
}

// ─────────────────────────────────────────────────────────────────────────────
// SHADER 4: compositeWater
//   Final full-screen pass: blends normal-mapped reflection + underwater scene.
//   Designed to run as a .colorEffect() or .layerEffect() in SwiftUI.
// ─────────────────────────────────────────────────────────────────────────────
[[stitchable]]
half4 compositeWater(float2         pos,
                     SwiftUI::Layer layer,
                     float2         size,
                     float          time,
                     float          waterlineY,    // 0..1 normalised Y of waterline
                     float          turbidity)     // 0 = clear, 1 = murky
{
    float2 uv   = pos / size;
    half4  col  = layer.sample(pos);

    // Above waterline → passthrough
    if (uv.y < waterlineY) return col;

    // Depth below waterline (0 at surface, 1 at bottom)
    float  d    = (uv.y - waterlineY) / (1.0 - waterlineY);

    // Underwater colour grading
    float3 underwaterTint = float3(0.02, 0.28, 0.50);
    float  fog            = 1.0 - exp(-d * turbidity * 3.0);
    float3 graded         = mix(float3(col.rgb), underwaterTint, fog * 0.7);

    // Chromatic aberration at waterline edge
    float  edgeDist = abs(uv.y - waterlineY);
    float  aberr    = smoothstep(0.04, 0.0, edgeDist) * 0.006;
    half   rChan    = layer.sample(float2(pos.x + aberr * size.x, pos.y)).r;
    half   bChan    = layer.sample(float2(pos.x - aberr * size.x, pos.y)).b;

    graded.r = mix(graded.r, float(rChan), 0.5);
    graded.b = mix(graded.b, float(bChan), 0.5);

    // Caustic overlay underwater
    float  c    = caustic(uv + float2(time * 0.05, 0), time, 2.8) * (1.0 - d) * 0.35;
    graded     += float3(0.30, 0.80, 1.00) * c;

    return half4(half3(graded), col.a);
}

