import SpriteKit

final class GoalNode: SKNode {
    
    private let concept: PhysicsConcept
    
    private let glowRing: SKShapeNode
    private let innerNode: SKShapeNode
    
    init(position: CGPoint, concept: PhysicsConcept) {
        self.concept = concept
        self.glowRing = SKShapeNode(circleOfRadius: 40)
        self.innerNode = SKShapeNode(circleOfRadius: 25)
        
        super.init()
        
        self.position = position
        self.zPosition = 50
        
        // Glow ring setup
        glowRing.lineWidth = 8
        glowRing.strokeColor = SKColor.cyan.withAlphaComponent(0.7)
        glowRing.fillColor = .clear
        glowRing.glowWidth = 8
        glowRing.zPosition = 50
        
        // Inner node setup
        innerNode.fillColor = SKColor.blue
        innerNode.strokeColor = SKColor.cyan
        innerNode.lineWidth = 2
        innerNode.zPosition = 51
        
        addChild(glowRing)
        addChild(innerNode)
        
        // Inner node pulsing
        let pulseUp = SKAction.scale(to: 1.1, duration: 1.0)
        let pulseDown = SKAction.scale(to: 0.9, duration: 1.0)
        let pulseSequence = SKAction.sequence([pulseUp, pulseDown])
        let pulseForever = SKAction.repeatForever(pulseSequence)
        innerNode.run(pulseForever)
    }
    
    required init?(coder aDecoder: NSCoder) {
        return nil
    }
    
    func celebrate() {
        // Stop inner node pulsing temporarily
        innerNode.removeAllActions()
        
        // Scale up and down
        let scaleUp = SKAction.scale(to: 1.4, duration: 0.3)
        let scaleDown = SKAction.scale(to: 1.0, duration: 0.3)
        let scaleSequence = SKAction.sequence([scaleUp, scaleDown])
        
        // Glow pulse
        let glowPulseUp = SKAction.customAction(withDuration: 0.3) { [weak self] node, elapsedTime in
            guard let glowRing = self?.glowRing else { return }
            let fraction = elapsedTime / 0.3
            glowRing.alpha = 0.7 + 0.3 * fraction
            glowRing.glowWidth = 8 + 4 * fraction
        }
        let glowPulseDown = SKAction.customAction(withDuration: 0.3) { [weak self] node, elapsedTime in
            guard let glowRing = self?.glowRing else { return }
            let fraction = elapsedTime / 0.3
            glowRing.alpha = 1.0 - 0.3 * fraction
            glowRing.glowWidth = 12 - 4 * fraction
        }
        let glowSequence = SKAction.sequence([glowPulseUp, glowPulseDown])
        
        // Sparkles emitter or fallback
        if let sparkEmitter = SKEmitterNode(fileNamed: "Sparkle.sks") {
            sparkEmitter.position = CGPoint.zero
            sparkEmitter.zPosition = 52
            sparkEmitter.numParticlesToEmit = 20
            sparkEmitter.particleLifetime = 1.0
            addChild(sparkEmitter)
            
            let emitterWait = SKAction.wait(forDuration: 1.0)
            let removeEmitter = SKAction.removeFromParent()
            sparkEmitter.run(SKAction.sequence([emitterWait, removeEmitter]))
        } else {
            // Fallback: create spark dots that fade out and move slightly outward
            let sparkleCount = 12
            let sparkleRadius: CGFloat = 45
            for i in 0..<sparkleCount {
                let angle = CGFloat(i) * (2 * .pi / CGFloat(sparkleCount))
                let sparkle = SKShapeNode(circleOfRadius: 3)
                sparkle.fillColor = SKColor.cyan
                sparkle.strokeColor = SKColor.clear
                sparkle.alpha = 0.0
                sparkle.position = CGPoint.zero
                sparkle.zPosition = 52
                addChild(sparkle)
                
                let moveOut = SKAction.moveBy(x: cos(angle)*sparkleRadius, y: sin(angle)*sparkleRadius, duration: 0.8)
                let fadeIn = SKAction.fadeAlpha(to: 1.0, duration: 0.2)
                let fadeOut = SKAction.fadeAlpha(to: 0, duration: 0.6)
                let fadeSequence = SKAction.sequence([fadeIn, fadeOut])
                let group = SKAction.group([moveOut, fadeSequence])
                let remove = SKAction.removeFromParent()
                sparkle.run(SKAction.sequence([group, remove]))
            }
        }
        
        // Run scale and glow pulse together, then resume inner node pulsing
        let celebrationGroup = SKAction.group([scaleSequence, glowSequence])
        let resumePulse = SKAction.run { [weak self] in
            guard let self = self else { return }
            let pulseUp = SKAction.scale(to: 1.1, duration: 1.0)
            let pulseDown = SKAction.scale(to: 0.9, duration: 1.0)
            let pulseSequence = SKAction.sequence([pulseUp, pulseDown])
            let pulseForever = SKAction.repeatForever(pulseSequence)
            self.innerNode.run(pulseForever)
        }
        
        run(SKAction.sequence([celebrationGroup, resumePulse]))
    }
}
