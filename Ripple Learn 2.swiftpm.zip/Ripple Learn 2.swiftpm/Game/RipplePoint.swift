// WaterRippleView.swift
// Metal GPU water system — SwiftUI wrapper + ViewModel.
// OceanBackground lives in GameView.swift — NOT here (avoids redeclaration).
//
// Requirements: iOS 17+, Shaders.metal compiled in same target.

import SwiftUI
import Combine

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - RipplePoint  (mirrors Metal float4: originX, originY, age, intensity)
// ─────────────────────────────────────────────────────────────────────────────

struct RipplePoint {
    var origin:    CGPoint
    var birthTime: Date
    var intensity: Float     // 0.5 – 2.0
    var isActive:  Bool

    static let inactive = RipplePoint(
        origin: .zero, birthTime: .distantPast, intensity: 0, isActive: false
    )

    func age(now: Date) -> Float {
        isActive ? Float(now.timeIntervalSince(birthTime)) : -1.0
    }

    func packed(now: Date) -> SIMD4<Float> {
        SIMD4(Float(origin.x), Float(origin.y), age(now: now), intensity)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - WaterViewModel  (@MainActor, ObservableObject)
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
final class WaterViewModel: ObservableObject {

    @Published var time:       Float = 0.0
    @Published var choppiness: Float = 0.65
    @Published var turbidity:  Float = 0.55
    // concept setter updates choppiness automatically
    @Published var concept: PhysicsConcept = .wavePropagation {
        didSet { choppiness = concept.metalChoppiness }
    }

    private let maxRipples = 16
    private(set) var ripples: [RipplePoint]
    private var nextSlot      = 0
    private var displayLink:  AnyCancellable?
    private let startDate     = Date()

    init(concept: PhysicsConcept = .wavePropagation) {
        ripples         = Array(repeating: .inactive, count: 16)
        self.concept    = concept
        self.choppiness = concept.metalChoppiness
        startTimer()
    }


    private func startTimer() {
        displayLink = Timer
            .publish(every: 1.0 / 120.0, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in self?.tick() }
    }

    private func tick() {
        time = Float(Date().timeIntervalSince(startDate))
        let now = Date()
        for i in ripples.indices where ripples[i].isActive {
            if ripples[i].age(now: now) > 4.0 { ripples[i].isActive = false }
        }
        objectWillChange.send()
    }

    func spawnRipple(at pt: CGPoint, intensity: Float = 1.0) {
        let slot = nextSlot % maxRipples
        ripples[slot] = RipplePoint(
            origin:    pt,
            birthTime: Date(),
            intensity: min(max(intensity, 0.5), 2.0),
            isActive:  true
        )
        nextSlot += 1
    }

    func packedRipples() -> [SIMD4<Float>] {
        let now = Date()
        return ripples.map { $0.packed(now: now) }
    }

    var activeRippleCount: Int {
        ripples.filter(\.isActive).count
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - [SIMD4<Float>] → Shader.Argument
// Single definition here — GameView.swift imports this, no duplicate needed.
// ─────────────────────────────────────────────────────────────────────────────

extension Array where Element == SIMD4<Float> {
    @available(iOS 17.0, *)
    var shaderArgument: Shader.Argument {
        withUnsafeBytes { .data(Data($0)) }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - WaterControlsView  (optional debug panel)
// ─────────────────────────────────────────────────────────────────────────────

struct WaterControlsView: View {
    @ObservedObject var vm: WaterViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Water Physics")
                .font(.system(.caption, design: .monospaced, weight: .bold))
                .foregroundColor(.white.opacity(0.6))

            Label("Choppiness  \(String(format: "%.2f", vm.choppiness))",
                  systemImage: "water.waves")
                .font(.caption).foregroundColor(.white.opacity(0.7))
            Slider(value: $vm.choppiness, in: 0...1.5).tint(.cyan)

            Label("Turbidity  \(String(format: "%.2f", vm.turbidity))",
                  systemImage: "drop.circle")
                .font(.caption).foregroundColor(.white.opacity(0.7))
            Slider(value: $vm.turbidity, in: 0...1).tint(.teal)
        }
        .padding(18)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.12)))
        .shadow(color: .black.opacity(0.4), radius: 16, y: 6)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - Previews
// ─────────────────────────────────────────────────────────────────────────────

#Preview("Water Controls") {
    ZStack {
        Color(red: 0.01, green: 0.05, blue: 0.12).ignoresSafeArea()
        WaterControlsView(vm: WaterViewModel(concept: .wavePropagation))
            .padding()
    }
    .preferredColorScheme(.dark)
}
