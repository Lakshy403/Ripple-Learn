import SpriteKit

class Ripple: SKNode {

    var currentRadius: CGFloat = 5
    private let maxRadius:  CGFloat = 350
    var spawnTime: TimeInterval = 0
    private let concept:    PhysicsConcept
    var intensity:          CGFloat
    private var ringShader: SKShader?
    private var subNodes:   [SKNode] = []

    init(concept: PhysicsConcept = .wavePropagation, intensity: CGFloat = 1.0) {
        self.concept   = concept
        self.intensity = intensity
        super.init()
        zPosition = 8
        spawnSplashParticles()
    }
    required init?(coder aDecoder: NSCoder) { fatalError() }

    func animate() {
        spawnTime = Date().timeIntervalSince1970
        spawnBaseRings()
        run(SKAction.sequence([
            SKAction.wait(forDuration: 0.016),
            SKAction.run { [weak self] in self?.buildShaderRing() }
        ]))
    }

    private func spawnBaseRings() {
        let dur: TimeInterval
        switch concept {
        case .resonance:      dur = 2.8
        case .complexSystems: dur = 2.6
        default:              dur = 2.5
        }

        switch concept {
        case .wavePropagation:
            expandRing(color: primaryColor(),              lw: 3.5, startR: 5, endR: maxRadius,        dur: dur,        glow: 8)
            expandRing(color: secondaryColor(),            lw: 2.0, startR: 5, endR: maxRadius * 0.82, dur: dur, delay: 0.18, glow: 5)
            expandRing(color: secondaryColor().safe(a:0.35), lw: 1.5, startR: 5, endR: maxRadius * 0.60, dur: dur, delay: 0.36, glow: 3)
        case .reflection:
            expandRing(color: primaryColor(),   lw: 4.0, startR: 5, endR: maxRadius,        dur: dur,        glow: 16)
            expandRing(color: secondaryColor(), lw: 2.0, startR: 5, endR: maxRadius * 0.90, dur: dur, delay: 0.08, glow: 6)
        case .interference:
            let off: CGFloat = 18.0 * min(intensity, 2.0)
            for sign: CGFloat in [-1.0, 1.0] {
                let src = SKNode()
                src.position = CGPoint(x: sign * off, y: 0)
                addChild(src); subNodes.append(src)
                expandRingOn(src, color: primaryColor(),   lw: 3.0, startR: 5, endR: maxRadius,        dur: dur,        glow: 8)
                expandRingOn(src, color: secondaryColor(), lw: 1.8, startR: 5, endR: maxRadius * 0.72, dur: dur, delay: 0.22, glow: 4)
            }
        case .refraction:
            let rgbColors: [SKColor] = [
                SKColor(red: 1.0, green: 0.3, blue: 0.3, alpha: 0.9),
                SKColor(red: 0.3, green: 1.0, blue: 0.3, alpha: 0.9),
                SKColor(red: 0.3, green: 0.5, blue: 1.0, alpha: 0.9),
            ]
            let offsets: [CGFloat] = [12, 0, -12]
            for (i, col) in rgbColors.enumerated() {
                expandRing(color: col, lw: 2.8, startR: 5, endR: maxRadius + offsets[i],
                           dur: dur, delay: Double(i) * 0.06, glow: 5)
            }
        case .resonance:
            expandRing(color: primaryColor(),                lw: 3.5, startR: 5, endR: maxRadius,        dur: dur,        glow: 12)
            expandRing(color: secondaryColor(),              lw: 2.5, startR: 4, endR: maxRadius * 0.50, dur: dur, delay: 0.10, glow: 7)
            expandRing(color: secondaryColor().safe(a: 0.5), lw: 1.5, startR: 3, endR: maxRadius * 0.25, dur: dur, delay: 0.20, glow: 4)
            let dot = SKShapeNode(circleOfRadius: 8)
            dot.fillColor = primaryColor().safe(a: 0.7); dot.strokeColor = .clear; dot.zPosition = 1
            addChild(dot)
            dot.run(SKAction.sequence([
                SKAction.group([SKAction.scale(to: 0.1, duration: dur), SKAction.fadeOut(withDuration: dur)]),
                SKAction.removeFromParent()
            ]))
        case .complexSystems:
            let hues: [CGFloat] = [0.58, 0.45, 0.32, 0.18, 0.08, 0.80]
            for (i, hue) in hues.enumerated() {
                let col = SKColor(hue: hue, saturation: 0.85, brightness: 1.0, alpha: 1.0)
                expandRing(color: col, lw: 3.0, startR: 5, endR: maxRadius * (1.0 - CGFloat(i) * 0.08),
                           dur: dur, delay: Double(i) * 0.12, glow: 8)
            }
        }

        trackRadius(to: maxRadius, duration: dur)
        run(SKAction.sequence([.wait(forDuration: dur + 0.15), .removeFromParent()]))
    }

    private func buildShaderRing() {
        guard parent != nil else { return }
        let side: CGFloat = maxRadius * 2 + 60
        let sprite = SKSpriteNode(color: .clear, size: CGSize(width: side, height: side))
        sprite.zPosition = 1
        let shader = SKShader(source: shaderSource(for: concept), uniforms: [
            SKUniform(name: "u_radius",    float: 0.0),
            SKUniform(name: "u_intensity", float: Float(intensity)),
            SKUniform(name: "u_alpha",     float: 1.0),
        ])
        sprite.shader = shader
        ringShader    = shader
        addChild(sprite)

        let dur: TimeInterval = (concept == .resonance) ? 2.8 : 2.6
        let expand = SKAction.customAction(withDuration: dur) { [weak self, weak shader] _, elapsed in
            guard let self, let shader else { return }
            let p     = CGFloat(elapsed) / CGFloat(dur)
            let eased = p * (2.0 - p)
            self.currentRadius = 5 + (self.maxRadius - 5) * eased
            let normR = Float(self.currentRadius / (side / 2.0))
            let alpha = Float(max(0.0, 1.0 - p * 1.1))
            shader.uniformNamed("u_radius")?.floatValue = normR
            shader.uniformNamed("u_alpha")?.floatValue  = alpha
        }
        sprite.run(SKAction.sequence([
            SKAction.group([expand, SKAction.fadeOut(withDuration: dur * 0.9)]),
            SKAction.removeFromParent()
        ]))
    }

    private func shaderSource(for concept: PhysicsConcept) -> String {
        let preamble = """
        uniform float u_radius;
        uniform float u_intensity;
        uniform float u_alpha;
        vec2 centredUV() { return v_tex_coord * 2.0 - 1.0; }
        float ringMask(vec2 uv, float r, float width, float soft) {
            float d = length(uv);
            return smoothstep(r - width - soft, r - width, d) * (1.0 - smoothstep(r, r + soft, d));
        }
        """
        switch concept {
        case .wavePropagation:
            return preamble + """
            void main() {
                vec2 uv = centredUV(); float r = u_radius;
                float ring = ringMask(uv, r, 0.04 * u_intensity, 0.02);
                float echo = ringMask(uv, r * 0.84, 0.015, 0.014) * 0.28;
                vec3 col = vec3(0.05, 0.72, 1.0) * (ring + echo);
                float halo = exp(-18.0 * pow(length(uv) - r, 2.0)) * 0.20;
                col += vec3(0.35, 0.88, 1.0) * halo;
                gl_FragColor = vec4(col, (ring + echo + halo * 0.5) * u_alpha);
            }
            """
        case .reflection:
            return preamble + """
            void main() {
                vec2 uv = centredUV(); float r = u_radius;
                float ang = atan(uv.y, uv.x);
                float spec = 0.5 + 0.5 * cos(ang * 8.0 + u_time * 3.0);
                float ring = ringMask(uv, r, 0.045 * u_intensity, 0.018);
                vec3 base = mix(vec3(0.6, 0.72, 0.92), vec3(0.95, 0.97, 1.0), spec);
                float refl = ringMask(uv, r + 0.01, 0.006, 0.005) * spec;
                vec3 col = base * ring + vec3(1.0) * refl;
                float halo = exp(-24.0 * pow(length(uv) - r, 2.0)) * 0.14;
                gl_FragColor = vec4(col + halo, (ring + refl * 0.5 + halo) * u_alpha);
            }
            """
        case .interference:
            return preamble + """
            void main() {
                vec2 uv = centredUV(); float r = u_radius;
                float d1 = length(uv - vec2(0.04, 0.0)); float d2 = length(uv + vec2(0.04, 0.0));
                float phase = cos((d1 - d2) * 28.0);
                float ring = ringMask(uv, r, 0.05 * u_intensity, 0.025);
                float fringe = (phase * 0.5 + 0.5) * ring;
                vec3 col = mix(vec3(0.25, 0.0, 0.7), vec3(0.72, 0.42, 1.0), fringe);
                float beat = (cos(length(uv) * 18.0 - u_time * 2.5) * 0.5 + 0.5) * ring * 0.35;
                col += vec3(0.52, 0.22, 0.9) * beat;
                gl_FragColor = vec4(col, ring * (0.5 + fringe * 0.5) * u_alpha);
            }
            """
        case .refraction:
            return preamble + """
            void main() {
                vec2 uv = centredUV(); float r = u_radius;
                float rR = ringMask(uv, r + 0.012, 0.030 * u_intensity, 0.018);
                float rG = ringMask(uv, r,          0.030 * u_intensity, 0.018);
                float rB = ringMask(uv, r - 0.012, 0.030 * u_intensity, 0.018);
                float dep = uv.y * 0.5 + 0.5;
                vec3 col = vec3(rR, rG, rB);
                col = mix(col, col.bgr, dep * 0.4);
                col += vec3(0.3, 1.0, 0.8) * pow(rG, 3.0) * 2.0;
                gl_FragColor = vec4(col, max(max(rR, rG), rB) * u_alpha);
            }
            """
        case .resonance:
            return preamble + """
            void main() {
                vec2 uv = centredUV(); float r = u_radius; float dist = length(uv);
                float f1 = ringMask(uv, r,        0.040 * u_intensity, 0.020);
                float f2 = ringMask(uv, r * 0.50, 0.020 * u_intensity, 0.012) * 0.65;
                float f3 = ringMask(uv, r * 0.25, 0.012 * u_intensity, 0.008) * 0.40;
                float all = f1 + f2 + f3;
                float glow = exp(-8.0 * pow(dist - r * 0.5, 2.0));
                float pulse = 0.5 + 0.5 * sin(u_time * 6.0);
                vec3 col = vec3(1.0, 0.58, 0.22) * all + vec3(1.0, 0.85, 0.55) * glow * pulse * 0.30;
                gl_FragColor = vec4(col, (all + glow * 0.2) * u_alpha);
            }
            """
        case .complexSystems:
            return preamble + """
            void main() {
                vec2 uv = centredUV(); float r = u_radius; float dist = length(uv);
                float ang = atan(uv.y, uv.x);
                float ring = ringMask(uv, r, 0.045 * u_intensity, 0.022);
                float hue = fract(ang / 6.28318 + r * 0.6 + u_time * 0.15);
                vec3 rgb = clamp(abs(mod(hue * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
                float r2 = ringMask(uv, r * 0.7, 0.018, 0.012) * 0.5;
                float r3 = ringMask(uv, r * 0.4, 0.010, 0.008) * 0.3;
                vec3 col = rgb * (ring + r2 + r3);
                col += rgb * exp(-18.0 * pow(dist - r, 2.0)) * 0.15;
                gl_FragColor = vec4(col, (ring + r2 + r3) * u_alpha);
            }
            """
        }
    }

    @discardableResult
    private func expandRing(color: SKColor, lw: CGFloat, startR: CGFloat, endR: CGFloat,
                             dur: TimeInterval, delay: TimeInterval = 0, glow: CGFloat = 6) -> SKShapeNode {
        let ring = makeRing(color: color, lw: lw, startR: startR, glow: glow)
        addChild(ring)
        driveRing(ring, color: color, lw: lw, glow: glow, startR: startR, endR: endR, dur: dur, delay: delay)
        return ring
    }

    private func expandRingOn(_ parent: SKNode, color: SKColor, lw: CGFloat, startR: CGFloat,
                               endR: CGFloat, dur: TimeInterval, delay: TimeInterval = 0, glow: CGFloat = 6) {
        let ring = makeRing(color: color, lw: lw, startR: startR, glow: glow)
        parent.addChild(ring)
        driveRing(ring, color: color, lw: lw, glow: glow, startR: startR, endR: endR, dur: dur, delay: delay)
    }

    private func makeRing(color: SKColor, lw: CGFloat, startR: CGFloat, glow: CGFloat) -> SKShapeNode {
        let r    = startR
        let ring = SKShapeNode()
        ring.path        = CGPath(ellipseIn: CGRect(x: -r, y: -r, width: r*2, height: r*2), transform: nil)
        ring.strokeColor = color
        ring.fillColor   = .clear
        ring.lineWidth   = lw
        ring.glowWidth   = glow
        ring.zPosition   = 0
        return ring
    }

    private func driveRing(_ ring: SKShapeNode, color: SKColor, lw: CGFloat, glow: CGFloat,
                            startR: CGFloat, endR: CGFloat, dur: TimeInterval, delay: TimeInterval) {
        let expand = SKAction.customAction(withDuration: dur) { node, elapsed in
            guard let s = node as? SKShapeNode else { return }
            let t    = CGFloat(elapsed) / CGFloat(dur)
            let ease = t * (2.0 - t)
            let r    = startR + (endR - startR) * ease
            s.path        = CGPath(ellipseIn: CGRect(x: -r, y: -r, width: r*2, height: r*2), transform: nil)
            s.lineWidth   = max(0.3, lw   * (1.0 - t * 0.7))
            s.glowWidth   = max(0.0, glow * (1.0 - t))
            s.strokeColor = color.safe(a: max(0.0, 1.0 - t * 1.05))
        }
        let seq: SKAction = delay > 0
            ? .sequence([.wait(forDuration: delay), expand, .removeFromParent()])
            : .sequence([expand, .removeFromParent()])
        ring.run(seq)
    }

    private func trackRadius(to endR: CGFloat, duration: TimeInterval) {
        run(SKAction.customAction(withDuration: duration) { [weak self] _, elapsed in
            guard let self else { return }
            let t = CGFloat(elapsed) / CGFloat(duration)
            self.currentRadius = 5.0 + (endR - 5.0) * t * (2.0 - t)
        })
    }

    private func primaryColor() -> SKColor {
        switch concept {
        case .wavePropagation: return SKColor(red: 0.20, green: 0.78, blue: 1.00, alpha: 1.0)
        case .reflection:      return SKColor(red: 0.78, green: 0.88, blue: 1.00, alpha: 1.0)
        case .interference:    return SKColor(red: 0.62, green: 0.40, blue: 1.00, alpha: 1.0)
        case .refraction:      return SKColor(red: 0.20, green: 1.00, blue: 0.78, alpha: 1.0)
        case .resonance:       return SKColor(red: 1.00, green: 0.62, blue: 0.22, alpha: 1.0)
        case .complexSystems:  return SKColor(red: 1.00, green: 0.38, blue: 0.85, alpha: 1.0)
        }
    }

    private func secondaryColor() -> SKColor {
        switch concept {
        case .wavePropagation: return SKColor(red: 0.50, green: 0.90, blue: 1.00, alpha: 0.60)
        case .reflection:      return SKColor(red: 0.92, green: 0.95, blue: 1.00, alpha: 0.60)
        case .interference:    return SKColor(red: 0.80, green: 0.55, blue: 1.00, alpha: 0.60)
        case .refraction:      return SKColor(red: 0.40, green: 1.00, blue: 0.85, alpha: 0.60)
        case .resonance:       return SKColor(red: 1.00, green: 0.80, blue: 0.50, alpha: 0.60)
        case .complexSystems:  return SKColor(red: 1.00, green: 0.65, blue: 0.95, alpha: 0.60)
        }
    }

    private func spawnSplashParticles() {
        let count = Int(12.0 * min(intensity, 2.0))
        let color = primaryColor()
        for i in 0..<count {
            let angle = CGFloat(i) / CGFloat(count) * .pi * 2.0
            let speed = CGFloat.random(in: 28...72) * min(intensity, 2.0)
            let r     = CGFloat.random(in: 1.8...3.8)
            let dot   = SKShapeNode(circleOfRadius: r)
            dot.fillColor = color; dot.strokeColor = .clear; dot.zPosition = 9
            addChild(dot)
            let dx = cos(angle) * speed; let dy = sin(angle) * speed
            let d  = TimeInterval(CGFloat.random(in: 0.22...0.42))
            let mv = SKAction.moveBy(x: dx, y: dy, duration: d); mv.timingMode = .easeOut
            dot.run(SKAction.sequence([
                SKAction.group([mv, SKAction.fadeOut(withDuration: d), SKAction.scale(to: 0.05, duration: d)]),
                SKAction.removeFromParent()
            ]))
        }
    }

    func getRadius() -> CGFloat { currentRadius }
}

private extension SKColor {
    func safe(a newAlpha: CGFloat) -> SKColor {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        if getRed(&r, green: &g, blue: &b, alpha: &a) {
            return SKColor(red: r, green: g, blue: b, alpha: newAlpha)
        }
        return SKColor(white: 1.0, alpha: newAlpha)
    }
}
