// GameScene.swift
// SpriteKit game scene — owns flower physics, goal detection, obstacle layout,
// and ripple force application.
//
// Metal GPU rings are rendered by WaterRippleView (SwiftUI layer above).
// Taps are forwarded here via .metalTapForwarded notification so both systems
// stay in sync without touching UIKit gesture recognisers directly.

import SpriteKit

class GameScene: SKScene {

    // ── Scene nodes ───────────────────────────────────────────────────────
    private var water:     WaterSurface!
    private var flower:    Flower!
    private var goal:      GoalNode!
    private var ripples:   [Ripple]        = []
    private var obstacles: [SKShapeNode]   = []

    // ── Game state ────────────────────────────────────────────────────────
    private var currentLevel       = 1
    private var levelCompleted     = false
    private var ripplesUsed        = 0
    private var levelStartTime:    TimeInterval = 0
    private var lastTapTime:       TimeInterval = 0
    private var currentConcept:    PhysicsConcept = .wavePropagation
    private var didShowHintThisLevel = false

    // ── Layout ────────────────────────────────────────────────────────────
    private var boundaryRect = CGRect.zero
    private var boundaryWall: SKShapeNode?

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Scene lifecycle
    // ─────────────────────────────────────────────────────────────────────

    override func didMove(to view: SKView) {
        self.size        = view.bounds.size
        self.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        backgroundColor  = .clear   // transparent — WaterRippleView shows through

        registerNotifications()
        computeBoundaryRect(view: view)

        water          = WaterSurface()
        water.position = .zero
        water.zPosition = 0
        addChild(water)
        water.didEnterScene()

        createBoundaryWall()
        setupLevel(currentLevel)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Notifications
    // ─────────────────────────────────────────────────────────────────────

    private func registerNotifications() {
        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(handleStartConcept(_:)),
                       name: .gameStartConcept,   object: nil)
        nc.addObserver(self, selector: #selector(handleMetalTap(_:)),
                       name: .metalTapForwarded,  object: nil)
    }

    @objc private func handleStartConcept(_ n: Notification) {
        if let c = n.object as? PhysicsConcept { currentConcept = c }
    }

    /// Metal layer forwards every tap/drag here so SpriteKit ripple physics
    /// remain in sync with the GPU ring visuals.
    @objc private func handleMetalTap(_ n: Notification) {
        guard !levelCompleted, let viewPt = n.object as? CGPoint else { return }
        // Convert UIKit view coordinates → SpriteKit scene coordinates
        guard let view else { return }
        let skPt = convertPoint(fromView: viewPt)
        spawnPhysicsRipple(at: skPt)
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Layout helpers
    // ─────────────────────────────────────────────────────────────────────

    private func computeBoundaryRect(view: SKView) {
        let safe = view.safeAreaInsets
        boundaryRect = CGRect(
            x:      -size.width  / 2 + safe.left   + 12,
            y:      -size.height / 2 + safe.bottom  + 90,
            width:   size.width  - safe.left - safe.right  - 24,
            height:  size.height - safe.top  - safe.bottom - 210
        )
    }

    private func createBoundaryWall() {
        boundaryWall?.removeFromParent()
        let path = CGMutablePath()
        path.addRoundedRect(in: boundaryRect, cornerWidth: 24, cornerHeight: 24)
        let wall = SKShapeNode(path: path)
        wall.strokeColor = SKColor(red: 0.20, green: 0.70, blue: 1.00, alpha: 0.28)
        wall.lineWidth   = 2
        wall.fillColor   = .clear
        wall.glowWidth   = 8
        wall.zPosition   = 1
        addChild(wall)
        boundaryWall = wall
        wall.run(SKAction.repeatForever(SKAction.sequence([
            SKAction.fadeAlpha(to: 0.14, duration: 2.0),
            SKAction.fadeAlpha(to: 0.40, duration: 2.0),
        ])))
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Level setup
    // ─────────────────────────────────────────────────────────────────────

    func setupLevel(_ level: Int) {
        flower?.removeFromParent()
        goal?.removeFromParent()
        obstacles.forEach { $0.removeFromParent() }
        obstacles.removeAll()
        ripples.removeAll()

        levelCompleted       = false
        ripplesUsed          = 0
        levelStartTime       = Date().timeIntervalSince1970
        lastTapTime          = 0
        didShowHintThisLevel = false
        HintSystem.shared.resetHintsForLevel()

        let difficulty  = AICoach.shared.getRecommendedDifficulty()
        let params      = DifficultyEngine.shared.getLevelParameters(level: level, difficulty: difficulty)
        currentConcept  = params.concept

        NotificationCenter.default.post(name: .gameLevelChanged,   object: level)
        NotificationCenter.default.post(name: .gameRipplesChanged, object: 0)
        NotificationCenter.default.post(name: .gameConceptChanged, object: currentConcept)

        let pos = getPositions(level: level)

        flower = Flower(position: pos.flower)
        addChild(flower)

        goal = GoalNode(position: pos.goal, concept: currentConcept)
        addChild(goal)

        createObstacles(level: level, flowerPos: pos.flower, goalPos: pos.goal)
        water.setupConceptEnvironment(concept: currentConcept, boundaryRect: boundaryRect)
    }

    private func getPositions(level: Int) -> (flower: CGPoint, goal: CGPoint) {
        let pad:  CGFloat = 55
        let safe = CGRect(
            x:      boundaryRect.minX + pad,
            y:      boundaryRect.minY + pad,
            width:  boundaryRect.width  - pad * 2,
            height: boundaryRect.height - pad * 2
        )
        let seed    = Double(level * 12345)
        let fX      = safe.minX + safe.width * 0.15
        let fY      = safe.minY + safe.height * CGFloat((sin(seed) + 1) / 2)
        let flower  = CGPoint(x: fX, y: fY)

        var goal    = CGPoint.zero
        var attempts = 0
        repeat {
            let gX = safe.maxX - safe.width * 0.15
            let gY = safe.minY + safe.height
                   * CGFloat((cos(seed + Double(attempts) * 123) + 1) / 2)
            goal     = CGPoint(x: gX, y: gY)
            attempts += 1
        } while hypot(goal.x - flower.x, goal.y - flower.y) < 240 && attempts < 10

        return (flower, goal)
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Obstacles
    // ─────────────────────────────────────────────────────────────────────

    private func createObstacles(level: Int, flowerPos: CGPoint, goalPos: CGPoint) {
        let count = min(level / 3, 5)
        for i in 0..<count {
            let seed = Double(level * 999 + i * 777)
            let t    = CGFloat((sin(seed) + 1) / 2) * 0.6 + 0.2
            let x    = flowerPos.x + (goalPos.x - flowerPos.x) * t
            let y    = flowerPos.y + (goalPos.y - flowerPos.y)
                     * CGFloat((cos(seed * 1.5) + 1) / 2)
            guard hypot(x - flowerPos.x, y - flowerPos.y) >= 80,
                  hypot(x - goalPos.x,   y - goalPos.y  ) >= 80 else { continue }
            let pos = CGPoint(x: x, y: y)
            i % 2 == 0 ? createStone(at: pos, size: CGFloat(20 + i * 5))
                       : createBranch(at: pos, angle: CGFloat(seed))
        }
    }

    private func createStone(at position: CGPoint, size s: CGFloat) {
        let pts: [CGPoint] = [
            CGPoint(x: -s*0.8, y: -s*0.6), CGPoint(x: -s*0.3, y: -s),
            CGPoint(x:  s*0.5, y: -s*0.7), CGPoint(x:  s,     y:  0),
            CGPoint(x:  s*0.6, y:  s*0.8), CGPoint(x: -s*0.2, y:  s),
            CGPoint(x: -s*0.9, y:  s*0.4),
        ]
        let path = CGMutablePath()
        path.move(to: pts[0])
        pts.dropFirst().forEach { path.addLine(to: $0) }
        path.closeSubpath()

        let stone         = SKShapeNode(path: path)
        stone.fillColor   = SKColor(red: 0.20, green: 0.30, blue: 0.40, alpha: 0.85)
        stone.strokeColor = SKColor(red: 0.35, green: 0.55, blue: 0.75, alpha: 0.65)
        stone.lineWidth   = 1.5
        stone.glowWidth   = 4
        stone.position    = position
        stone.zPosition   = 6
        addChild(stone)
        obstacles.append(stone)
    }

    private func createBranch(at position: CGPoint, angle: CGFloat) {
        let path = CGMutablePath()
        path.addRoundedRect(in: CGRect(x: -3.5, y: 0, width: 7, height: 60),
                            cornerWidth: 3.5, cornerHeight: 3.5)
        let branch         = SKShapeNode(path: path)
        branch.fillColor   = SKColor(red: 0.18, green: 0.28, blue: 0.38, alpha: 0.85)
        branch.strokeColor = SKColor(red: 0.30, green: 0.50, blue: 0.70, alpha: 0.55)
        branch.lineWidth   = 1
        branch.glowWidth   = 3
        branch.position    = position
        branch.zRotation   = angle
        branch.zPosition   = 6
        addChild(branch)
        obstacles.append(branch)
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Touch (SpriteKit fallback — Metal layer is primary)
    // ─────────────────────────────────────────────────────────────────────

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // NOTE: WaterRippleView's DragGesture intercepts touches first and
        // posts .metalTapForwarded. This fallback fires only if the Metal
        // layer is unavailable (e.g. Simulator / iOS 16).
        guard !levelCompleted, let touch = touches.first else { return }
        spawnPhysicsRipple(at: touch.location(in: self))
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Physics ripple spawning
    // ─────────────────────────────────────────────────────────────────────

    private func spawnPhysicsRipple(at location: CGPoint) {
        guard !levelCompleted else { return }
        let now      = Date().timeIntervalSince1970
        let gap      = now - lastTapTime
        lastTapTime  = now
        let intensity: CGFloat = gap < 0.5 ? 2.0 : gap < 1.0 ? 1.5 : 1.0

        let difficulty = AICoach.shared.getRecommendedDifficulty()
        let params     = DifficultyEngine.shared.getLevelParameters(level: currentLevel,
                                                                     difficulty: difficulty)
        let ripple = water.spawnRipple(at: location, concept: params.concept, intensity: intensity)
        ripples.append(ripple)
        ripplesUsed += 1
        NotificationCenter.default.post(name: .gameRipplesChanged, object: ripplesUsed)
        if intensity > 1.0 { showIntensityFeedback(at: location, intensity: intensity) }
    }

    private func showIntensityFeedback(at pos: CGPoint, intensity: CGFloat) {
        let lbl       = SKLabelNode(text: "×\(String(format: "%.1f", intensity))")
        lbl.fontSize  = 20
        lbl.fontName  = "AvenirNext-Bold"
        lbl.fontColor = intensity >= 2.0
            ? SKColor(red: 1.0, green: 0.55, blue: 0.1, alpha: 1)
            : SKColor(red: 0.2, green: 0.9,  blue: 1.0, alpha: 1)
        lbl.position  = pos
        lbl.zPosition = 150
        addChild(lbl)
        lbl.run(SKAction.sequence([
            SKAction.group([
                SKAction.fadeOut(withDuration: 0.5),
                SKAction.moveBy(x: 0, y: 40, duration: 0.5),
            ]),
            SKAction.removeFromParent(),
        ]))
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Game loop
    // ─────────────────────────────────────────────────────────────────────

    override func update(_ currentTime: TimeInterval) {
        guard !levelCompleted else { return }

        flower.update()
        handleBoundaryCollision()
        checkObstacleCollision()

        let difficulty = AICoach.shared.getRecommendedDifficulty()
        let params     = DifficultyEngine.shared.getLevelParameters(level: currentLevel,
                                                                     difficulty: difficulty)
        var alive: [Ripple] = []
        for r in ripples where r.parent != nil && currentTime - r.spawnTime < 6.0 {
            alive.append(r)
            applyConceptForce(ripple: r, concept: params.concept)
        }
        ripples = alive

        // Goal check
        if hypot(flower.position.x - goal.position.x,
                 flower.position.y - goal.position.y) < 52 {
            levelCompleted = true
            showLevelComplete()
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Collision & physics
    // ─────────────────────────────────────────────────────────────────────

    private func handleBoundaryCollision() {
        var pos = flower.position
        var vel = flower.getVelocity()
        var hit = false
        if pos.x < boundaryRect.minX { pos.x = boundaryRect.minX; vel.dx =  abs(vel.dx)*0.8; hit = true }
        if pos.x > boundaryRect.maxX { pos.x = boundaryRect.maxX; vel.dx = -abs(vel.dx)*0.8; hit = true }
        if pos.y < boundaryRect.minY { pos.y = boundaryRect.minY; vel.dy =  abs(vel.dy)*0.8; hit = true }
        if pos.y > boundaryRect.maxY { pos.y = boundaryRect.maxY; vel.dy = -abs(vel.dy)*0.8; hit = true }
        if hit { flower.position = pos; flower.setVelocity(vel) }
    }

    private func checkObstacleCollision() {
        for obs in obstacles {
            let d = hypot(flower.position.x - obs.position.x,
                          flower.position.y - obs.position.y)
            guard d < 42 else { continue }
            let angle = atan2(flower.position.y - obs.position.y,
                              flower.position.x - obs.position.x)
            let speed = hypot(flower.getVelocity().dx, flower.getVelocity().dy)
            flower.setVelocity(CGVector(dx: cos(angle)*speed*0.7, dy: sin(angle)*speed*0.7))
            flower.position.x += cos(angle) * (42 - d)
            flower.position.y += sin(angle) * (42 - d)
        }
    }

    private func applyConceptForce(ripple: Ripple, concept: PhysicsConcept) {
        let dist   = hypot(flower.position.x - ripple.position.x,
                           flower.position.y - ripple.position.y)
        let inRing = dist < ripple.currentRadius && dist > ripple.currentRadius - 55

        func push(base: CGFloat, mult: CGFloat = 1.0) {
            guard inRing else { return }
            let angle = atan2(flower.position.y - ripple.position.y,
                              flower.position.x - ripple.position.x)
            let f = base * max(0, 1 - dist / ripple.currentRadius) * mult * ripple.intensity
            flower.applyForce(CGVector(dx: cos(angle)*f, dy: sin(angle)*f))
        }

        switch concept {
        case .wavePropagation:
            push(base: 3.0)

        case .reflection:
            push(base: 3.5)
            applyBoundaryReflection(ripple: ripple)
            applyWallReflection(ripple: ripple)

        case .interference:
            let bonus: CGFloat = 1 + CGFloat(ripples.filter {
                $0 !== ripple &&
                hypot(flower.position.x - $0.position.x,
                      flower.position.y - $0.position.y) < $0.currentRadius
            }.count) * 0.5
            push(base: 2.5, mult: bonus)

        case .refraction:
            push(base: 3.0, mult: flower.position.y > 0 ? 0.6 : 1.2)

        case .resonance:
            push(base: 3.0, mult: ripples.count > 2 ? 1.5 : 1.0)

        case .complexSystems:
            let bonus: CGFloat = 1 + CGFloat(ripples.filter {
                $0 !== ripple &&
                hypot(flower.position.x - $0.position.x,
                      flower.position.y - $0.position.y) < $0.currentRadius
            }.count) * 0.3
            push(base: 3.0, mult: (flower.position.y > 0 ? 0.7 : 1.3) * bonus)
            applyBoundaryReflection(ripple: ripple)
            applyWallReflection(ripple: ripple)
        }
    }

    private func applyBoundaryReflection(ripple: Ripple) {
        let walls: [(CGFloat, Bool)] = [
            (boundaryRect.minX, true), (boundaryRect.maxX, true),
            (boundaryRect.minY, false),(boundaryRect.maxY, false),
        ]
        for (pos, vertical) in walls {
            let d = vertical
                ? abs(ripple.position.x - pos)
                : abs(ripple.position.y - pos)
            guard d < ripple.currentRadius && d > ripple.currentRadius - 55 else { continue }
            let fd = hypot(flower.position.x - ripple.position.x,
                           flower.position.y - ripple.position.y)
            guard fd < ripple.currentRadius + 100 else { continue }
            var dx = flower.position.x - ripple.position.x
            var dy = flower.position.y - ripple.position.y
            if vertical { dx = -dx * 1.2 } else { dy = -dy * 1.2 }
            let angle = atan2(dy, dx)
            let f = max(0, 1 - fd / (ripple.currentRadius + 100)) * 2.0 * ripple.intensity
            flower.applyForce(CGVector(dx: cos(angle)*f, dy: sin(angle)*f))
        }
    }

    private func applyWallReflection(ripple: Ripple) {
        for wall in water.getReflectionWalls() {
            guard let wp = wall.path else { continue }
            let wb = wp.boundingBox
            let d  = abs(ripple.position.x - wb.midX)
            guard d < ripple.currentRadius && d > ripple.currentRadius - 55 else { continue }
            let fd = hypot(flower.position.x - ripple.position.x,
                           flower.position.y - ripple.position.y)
            guard fd < ripple.currentRadius else { continue }
            let angle = atan2( flower.position.y - ripple.position.y,
                              -(flower.position.x - ripple.position.x))
            let f = max(0, 1 - fd / ripple.currentRadius) * 2.5 * ripple.intensity
            flower.applyForce(CGVector(dx: cos(angle)*f, dy: sin(angle)*f))
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // MARK: - Level complete
    // ─────────────────────────────────────────────────────────────────────

    private func showLevelComplete() {
        let timeSpent  = Date().timeIntervalSince1970 - levelStartTime
        let difficulty = AICoach.shared.getRecommendedDifficulty()
        let params     = DifficultyEngine.shared.getLevelParameters(level: currentLevel,
                                                                     difficulty: difficulty)
        ProgressTracker.shared.completeLevel(currentLevel, time: timeSpent, concept: params.concept)
        AICoach.shared.recordAttempt(success: true, time: timeSpent,
                                     hintsUsed: didShowHintThisLevel ? 1 : 0)

        NotificationCenter.default.post(name: .levelComplete,
                                        object: "Level \(currentLevel) Complete!")
        goal.celebrate()

        DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) { [weak self] in
            guard let self else { return }
            self.currentLevel += 1
            self.setupLevel(self.currentLevel)
        }
    }
}
