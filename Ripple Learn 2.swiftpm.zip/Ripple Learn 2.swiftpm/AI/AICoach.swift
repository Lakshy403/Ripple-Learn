import Foundation

// ─────────────────────────────────────────────────────────────────────────────
// AICoach.swift  —  Adaptive difficulty coach
// Tracks player performance and recommends difficulty adjustments
// ─────────────────────────────────────────────────────────────────────────────

enum DifficultyLevel: String, CaseIterable {
    case easy    = "Easy"
    case normal  = "Normal"
    case hard    = "Hard"
}

struct AttemptRecord {
    let success:    Bool
    let timeSpent:  Double
    let hintsUsed:  Int
    let timestamp:  Date
}

final class AICoach {
    @MainActor static let shared = AICoach()

    private var recentAttempts: [AttemptRecord] = []
    private let maxHistory = 10

    // Persisted difficulty
    private var currentDifficulty: DifficultyLevel = .normal

    private init() {
        loadDifficulty()
    }

    // MARK: - Public API

    func getRecommendedDifficulty() -> DifficultyLevel {
        return currentDifficulty
    }

    func recordAttempt(success: Bool, time: Double, hintsUsed: Int) {
        let record = AttemptRecord(success: success, timeSpent: time,
                                   hintsUsed: hintsUsed, timestamp: Date())
        recentAttempts.append(record)
        if recentAttempts.count > maxHistory {
            recentAttempts.removeFirst()
        }
        recalibrate()
    }

    func getPerformanceSummary() -> String {
        guard !recentAttempts.isEmpty else { return "Keep playing to get personalised tips!" }
        let successRate = Double(recentAttempts.filter { $0.success }.count) / Double(recentAttempts.count)
        let avgTime = recentAttempts.map { $0.timeSpent }.reduce(0, +) / Double(recentAttempts.count)
        if successRate >= 0.8 && avgTime < 30 {
            return "Excellent work! You're mastering wave physics quickly."
        } else if successRate >= 0.6 {
            return "Good progress! Try experimenting with tap timing for better results."
        } else {
            return "Keep practising! Focus on creating ripples closer to the flower."
        }
    }

    func getSkillScore(for concept: PhysicsConcept) -> Double {
        let relevant = recentAttempts.suffix(5)
        guard !relevant.isEmpty else { return 0.0 }
        let rate = Double(relevant.filter { $0.success }.count) / Double(relevant.count)
        return min(rate * 100, 100)
    }

    // MARK: - Private

    private func recalibrate() {
        guard recentAttempts.count >= 3 else { return }
        let last = recentAttempts.suffix(5)
        let rate = Double(last.filter { $0.success }.count) / Double(last.count)
        let avgHints = last.map { Double($0.hintsUsed) }.reduce(0, +) / Double(last.count)

        if rate >= 0.85 && avgHints < 0.5 {
            currentDifficulty = .hard
        } else if rate < 0.40 || avgHints > 1.5 {
            currentDifficulty = .easy
        } else {
            currentDifficulty = .normal
        }
        saveDifficulty()
    }

    private func saveDifficulty() {
        UserDefaults.standard.set(currentDifficulty.rawValue, forKey: "aiCoachDifficulty")
    }

    private func loadDifficulty() {
        if let raw = UserDefaults.standard.string(forKey: "aiCoachDifficulty"),
           let d = DifficultyLevel(rawValue: raw) {
            currentDifficulty = d
        }
    }
}
