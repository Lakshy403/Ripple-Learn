import Foundation

// ─────────────────────────────────────────────────────────────────────────────
// HintSystem.swift  —  Contextual in-game hint provider
// ─────────────────────────────────────────────────────────────────────────────

final class HintSystem {
    @MainActor static let shared = HintSystem()

    private var hintsShownThisLevel: Set<String> = []
    private var tapCount = 0

    private init() {}

    // MARK: - Public API

    func resetHintsForLevel() {
        hintsShownThisLevel.removeAll()
        tapCount = 0
    }

    func getConceptHint(concept: PhysicsConcept) -> String {
        switch concept {
        case .wavePropagation:
            return "Tap anywhere on the water to create a ripple. The wave will push the flower outward — aim your tap carefully!"
        case .reflection:
            return "Waves bounce off the glass walls at equal angles. Try tapping so the reflected wave redirects the flower toward the goal."
        case .interference:
            return "Create multiple overlapping ripples! When two wave fronts meet, they combine their force — time your taps for maximum power."
        case .refraction:
            return "The water is split into shallow (slow) and deep (fast) zones. Waves change speed at the boundary, bending toward the slower region."
        case .resonance:
            return "Tap with a steady rhythm! When 3 or more ripples are active simultaneously, a resonance bonus of ×1.5 kicks in."
        case .complexSystems:
            return "All physics rules are active at once. Use reflections, interference, and refraction zones together to guide the flower."
        }
    }

    func getTapProgressHint(tapCount: Int, concept: PhysicsConcept) -> String? {
        self.tapCount = tapCount
        switch (tapCount, concept) {
        case (3, .wavePropagation):
            return "Try tapping faster — consecutive taps under 0.5 s give a ×2 force boost!"
        case (5, .interference):
            return "You have multiple waves active — watch for the bright interference fringes!"
        case (3, .resonance):
            return "Keep tapping at the same rhythm to build resonance energy."
        default:
            return nil
        }
    }

    func getStuckHint(concept: PhysicsConcept, attempts: Int) -> String {
        if attempts < 3 { return getConceptHint(concept: concept) }
        switch concept {
        case .wavePropagation:
            return "Try tapping directly behind the flower (opposite to the goal) so the wave pushes it forward."
        case .reflection:
            return "Aim your tap at the wall rather than directly at the flower — let the reflection do the work."
        case .interference:
            return "Tap two spots on opposite sides of the flower almost simultaneously for a powerful burst."
        case .refraction:
            return "Tap in the deep (dark-blue) zone — waves move faster there and deliver more momentum."
        case .resonance:
            return "Count: tap … wait … tap … wait. A consistent 1-second rhythm builds the strongest resonance."
        case .complexSystems:
            return "Plan a multi-step path: first reflect a wave off a wall, then add a second tap for interference."
        }
    }
}
