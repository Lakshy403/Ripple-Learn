import Foundation

// ─────────────────────────────────────────────────────────────────────────────
// DifficultyEngine.swift  —  Maps level + difficulty → LevelParameters
// ─────────────────────────────────────────────────────────────────────────────

struct LevelParameters {
    let concept:        PhysicsConcept
    let maxRipples:     Int      // 0 = unlimited
    let timeLimit:      Double   // seconds, 0 = unlimited
    let obstacleCount:  Int
    let goalRadius:     Double   // px — larger = easier
}

final class DifficultyEngine {
    @MainActor static let shared = DifficultyEngine()
    private init() {}

    // Concept progression: every 5 levels introduces the next concept
    private func concept(for level: Int) -> PhysicsConcept {
        switch level {
        case 1...5:   return .wavePropagation
        case 6...10:  return .reflection
        case 11...15: return .interference
        case 16...20: return .refraction
        case 21...25: return .resonance
        default:      return .complexSystems
        }
    }

    func getLevelParameters(level: Int, difficulty: DifficultyLevel) -> LevelParameters {
        let base = concept(for: level)

        switch difficulty {
        case .easy:
            return LevelParameters(
                concept:       base,
                maxRipples:    0,
                timeLimit:     0,
                obstacleCount: max(0, level / 5 - 1),
                goalRadius:    65
            )
        case .normal:
            return LevelParameters(
                concept:       base,
                maxRipples:    0,
                timeLimit:     0,
                obstacleCount: level / 3,
                goalRadius:    52
            )
        case .hard:
            return LevelParameters(
                concept:       base,
                maxRipples:    5 + level / 2,
                timeLimit:     60,
                obstacleCount: min(level / 2, 6),
                goalRadius:    38
            )
        }
    }
}
