import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens — identical to LevelsTabView and ConceptsView
// ─────────────────────────────────────────────────────────────────────────────
private enum DS {
    static let bg0  = Color(red: 0.01, green: 0.05, blue: 0.12)
    static let bg1  = Color(red: 0.00, green: 0.12, blue: 0.24)
    static let cyan = Color(red: 0.20, green: 0.82, blue: 1.00)
    static let teal = Color(red: 0.00, green: 0.90, blue: 0.72)  // harmonised from (0,1,0.8) → softer
    static let gold = Color(red: 1.00, green: 0.75, blue: 0.20)
    static let font = "AvenirNext-Medium"
    static let bold = "AvenirNext-Bold"
    static let demi = "AvenirNext-DemiBold"

    // Glass card — same recipe used by LevelsTabView cards
    static func glassCard(accent: Color = .white) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20).fill(.ultraThinMaterial)
            RoundedRectangle(cornerRadius: 20).fill(accent.opacity(0.04))
            RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.10), lineWidth: 1)
            // Top-edge sheen
            RoundedRectangle(cornerRadius: 20)
                .fill(
                    LinearGradient(
                        colors: [.white.opacity(0.09), .clear],
                        startPoint: .top, endPoint: .center
                    )
                )
        }
        .shadow(color: .black.opacity(0.35), radius: 16, y: 6)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ProgressDashboardView
// ─────────────────────────────────────────────────────────────────────────────
struct ProgressDashboardView: View {
    @StateObject private var vm = ProgressDashboardViewModel()
    @EnvironmentObject private var appState: AppState
    @State private var appeared = false

    var body: some View {
        ZStack {
            // Matching gradient
            LinearGradient(
                colors: [DS.bg0, DS.bg1],
                startPoint: .topLeading,
                endPoint:   .bottomTrailing
            )
            .ignoresSafeArea()

            CausticOverlay().ignoresSafeArea().opacity(0.35)

            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {

                    headerSection
                        .padding(.top, 20)

                    overallStatsRow
                        .opacity(appeared ? 1 : 0).offset(y: appeared ? 0 : 20)
                        .animation(.easeOut(duration: 0.5).delay(0.10), value: appeared)

                    conceptMasterySection
                        .opacity(appeared ? 1 : 0).offset(y: appeared ? 0 : 20)
                        .animation(.easeOut(duration: 0.5).delay(0.20), value: appeared)

                    progressChartSection
                        .opacity(appeared ? 1 : 0).offset(y: appeared ? 0 : 20)
                        .animation(.easeOut(duration: 0.5).delay(0.30), value: appeared)

                    aiCard
                        .opacity(appeared ? 1 : 0).offset(y: appeared ? 0 : 20)
                        .animation(.easeOut(duration: 0.5).delay(0.40), value: appeared)

                    recentSection
                        .opacity(appeared ? 1 : 0).offset(y: appeared ? 0 : 20)
                        .animation(.easeOut(duration: 0.5).delay(0.50), value: appeared)

                    Spacer(minLength: 90)
                }
                .padding(.horizontal, 18)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .onAppear {
            vm.refresh()
            withAnimation { appeared = true }
        }
        .onReceive(appState.$selectedTab) { tab in
            if tab == 2 { vm.refresh() }
        }
    }

    // MARK: - Header (matches LevelsTabView header style)
    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Progress")
                .font(.system(size: 28, weight: .black, design: .rounded))
                .foregroundStyle(
                    LinearGradient(
                        colors: [.white, DS.cyan],
                        startPoint: .leading, endPoint: .trailing
                    )
                )
            Text("Your physics learning journey")
                .font(.custom(DS.font, size: 14))
                .foregroundColor(.white.opacity(0.55))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - Stats row
    private var overallStatsRow: some View {
        HStack(spacing: 12) {
            StatBubble(value: "\(vm.levelsCompleted)", label: "Levels",
                       icon: "checkmark.seal.fill",   color: DS.cyan)
            StatBubble(value: "\(Int(vm.overallMastery))%", label: "Mastery",
                       icon: "brain.head.profile",    color: DS.teal)
            StatBubble(value: "\(vm.highestLevel)",   label: "Best Level",
                       icon: "trophy.fill",            color: DS.gold)
        }
    }

    // MARK: - Concept mastery
    private var conceptMasterySection: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "Concept Mastery", icon: "waveform.path")
            ForEach(PhysicsConcept.allCases) { concept in
                ConceptMasteryRow(concept: concept, score: vm.masteryScore(for: concept))
            }
        }
        .padding(18)
        .background(DS.glassCard())
    }

    // MARK: - Progress chart
    private var progressChartSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "Level Progress", icon: "chart.line.uptrend.xyaxis")
            LevelProgressChart(completed: vm.levelsCompleted, total: 30)
                .frame(height: 80)
        }
        .padding(18)
        .background(DS.glassCard())
    }

    // MARK: - AI Coach card
    // Uses a cyan→purple gradient border — consistent with the app's accent usage
    private var aiCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                Image(systemName: "sparkles")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(DS.cyan)
                Text("AI Coach")
                    .font(.custom(DS.bold, size: 15))
                    .foregroundColor(.white)
                Spacer()
                Text("Personalised")
                    .font(.custom(DS.font, size: 10))
                    .tracking(1)
                    .foregroundColor(DS.cyan.opacity(0.6))
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(Capsule().fill(DS.cyan.opacity(0.12)))
            }

            Text(vm.aiSummary)
                .font(.custom(DS.font, size: 14))
                .foregroundColor(.white.opacity(0.80))
                .lineSpacing(4)

            if let next = vm.recommendedNextConcept {
                HStack(spacing: 10) {
                    Text(next.emoji).font(.system(size: 20))
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Try next:")
                            .font(.custom(DS.font, size: 11))
                            .foregroundColor(.white.opacity(0.45))
                        Text(next.shortName)
                            .font(.custom(DS.bold, size: 14))
                            .foregroundColor(next.accentColor)
                    }
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(next.accentColor.opacity(0.08))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(next.accentColor.opacity(0.25), lineWidth: 1)
                        )
                )
            }
        }
        .padding(18)
        .background(
            ZStack {
                RoundedRectangle(cornerRadius: 20).fill(.ultraThinMaterial)
                // Subtle cyan tint — consistent with card accent pattern
                RoundedRectangle(cornerRadius: 20).fill(DS.cyan.opacity(0.04))
                RoundedRectangle(cornerRadius: 20)
                    .stroke(
                        LinearGradient(
                            colors: [DS.cyan.opacity(0.45), Color(red: 0.55, green: 0.28, blue: 1).opacity(0.45)],
                            startPoint: .topLeading, endPoint: .bottomTrailing
                        ),
                        lineWidth: 1
                    )
                RoundedRectangle(cornerRadius: 20)
                    .fill(
                        LinearGradient(
                            colors: [.white.opacity(0.09), .clear],
                            startPoint: .top, endPoint: .center
                        )
                    )
            }
            .shadow(color: DS.cyan.opacity(0.12), radius: 20, y: 6)
        )
    }

    // MARK: - Recent activity
    private var recentSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            SectionHeader(title: "Recent Activity", icon: "clock.arrow.circlepath")
            if vm.recentLevels.isEmpty {
                VStack(spacing: 12) {
                    Image(systemName: "gamecontroller")
                        .font(.system(size: 32))
                        .foregroundColor(DS.cyan.opacity(0.4))
                    Text("Complete your first level to see activity here.")
                        .font(.custom(DS.font, size: 13))
                        .foregroundColor(.white.opacity(0.40))
                        .multilineTextAlignment(.center)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 20)
            } else {
                ForEach(vm.recentLevels, id: \.level) { RecentLevelRow(record: $0) }
            }
        }
        .padding(18)
        .background(DS.glassCard())
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Sub-views
// ─────────────────────────────────────────────────────────────────────────────

private struct SectionHeader: View {
    let title: String; let icon: String
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(DS.cyan)
            Text(title)
                .font(.custom(DS.bold, size: 15))
                .foregroundColor(.white)
        }
    }
}

private struct StatBubble: View {
    let value: String; let label: String; let icon: String; let color: Color
    @State private var appeared = false

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.system(size: 20, weight: .semibold))
                .foregroundColor(color)
                .shadow(color: color.opacity(0.6), radius: 6)
            Text(value)
                .font(.custom(DS.bold, size: 22))
                .foregroundColor(.white)
            Text(label)
                .font(.custom(DS.font, size: 10))
                .tracking(1)
                .foregroundColor(.white.opacity(0.40))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 18)
        .background(
            ZStack {
                RoundedRectangle(cornerRadius: 18).fill(.ultraThinMaterial)
                RoundedRectangle(cornerRadius: 18).fill(color.opacity(0.04))
                RoundedRectangle(cornerRadius: 18).stroke(color.opacity(0.22), lineWidth: 1)
                RoundedRectangle(cornerRadius: 18)
                    .fill(
                        LinearGradient(
                            colors: [.white.opacity(0.10), .clear],
                            startPoint: .top, endPoint: .center
                        )
                    )
            }
            .shadow(color: color.opacity(0.15), radius: 12, y: 4)
        )
        .scaleEffect(appeared ? 1 : 0.85)
        .opacity(appeared ? 1 : 0)
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.65).delay(0.1)) {
                appeared = true
            }
        }
    }
}

struct ConceptMasteryRow: View {
    let concept: PhysicsConcept; let score: Double
    @State private var animScore: Double = 0

    var body: some View {
        if #available(iOS 17.0, *) {
            VStack(spacing: 6) {
                HStack {
                    Text(concept.emoji).font(.system(size: 16))
                    Text(concept.shortName)
                        .font(.custom(DS.demi, size: 13))
                        .foregroundColor(.white.opacity(0.85))
                    Spacer()
                    Text("\(Int(animScore))%")
                        .font(.custom(DS.bold, size: 13))
                        .foregroundColor(concept.accentColor)
                        .shadow(color: concept.accentColor.opacity(0.4), radius: 4)
                }
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        RoundedRectangle(cornerRadius: 4)
                            .fill(Color.white.opacity(0.06))
                            .frame(height: 6)
                        RoundedRectangle(cornerRadius: 4)
                            .fill(
                                LinearGradient(
                                    colors: [concept.accentColor.opacity(0.7), concept.accentColor],
                                    startPoint: .leading, endPoint: .trailing
                                )
                            )
                            .frame(width: geo.size.width * CGFloat(animScore / 100), height: 6)
                            .shadow(color: concept.accentColor.opacity(0.5), radius: 4)
                        Circle()
                            .fill(concept.accentColor)
                            .frame(width: 8, height: 8)
                            .shadow(color: concept.accentColor, radius: 5)
                            .offset(x: geo.size.width * CGFloat(animScore / 100) - 4)
                            .opacity(animScore > 2 ? 1 : 0)
                    }
                    .frame(height: 8)
                }
                .frame(height: 8)
            }
            .onAppear {
                withAnimation(.easeOut(duration: 1.2).delay(0.3)) { animScore = score }
            }
            .onChange(of: score) { _, v in
                withAnimation(.easeOut(duration: 0.8)) { animScore = v }
            }
        } else {
            HStack {
                Text(concept.emoji).font(.system(size: 16))
                Text(concept.shortName)
                    .font(.custom(DS.demi, size: 13))
                    .foregroundColor(.white.opacity(0.85))
                Spacer()
                Text("\(Int(score))%")
                    .font(.custom(DS.bold, size: 13))
                    .foregroundColor(concept.accentColor)
            }
        }
    }
}

private struct LevelProgressChart: View {
    let completed: Int; let total: Int
    var body: some View {
        GeometryReader { geo in
            let barW = (geo.size.width - CGFloat(total - 1) * 2) / CGFloat(total)
            HStack(spacing: 2) {
                ForEach(0..<total, id: \.self) { i in
                    let done = i < completed
                    RoundedRectangle(cornerRadius: 3)
                        .fill(
                            done
                            ? LinearGradient(colors: [DS.teal, DS.cyan], startPoint: .bottom, endPoint: .top)
                            : LinearGradient(colors: [.white.opacity(0.06), .white.opacity(0.06)], startPoint: .bottom, endPoint: .top)
                        )
                        .frame(width: barW, height: geo.size.height * (done ? 1.0 : 0.2))
                        .frame(height: geo.size.height, alignment: .bottom)
                        .shadow(color: done ? DS.cyan.opacity(0.5) : .clear, radius: 4)
                }
            }
        }
    }
}

private struct RecentLevelRow: View {
    let record: LevelRecord
    private var concept: PhysicsConcept? {
        PhysicsConcept.allCases.first { $0.rawValue == record.concept }
    }
    var body: some View {
        HStack(spacing: 12) {
            if let c = concept { Text(c.emoji).font(.system(size: 22)) }
            VStack(alignment: .leading, spacing: 3) {
                Text("Level \(record.level)")
                    .font(.custom(DS.bold, size: 14))
                    .foregroundColor(.white)
                Text(record.concept)
                    .font(.custom(DS.font, size: 11))
                    .foregroundColor(.white.opacity(0.45))
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 3) {
                Text(String(format: "%.1f s", record.timeSpent))
                    .font(.custom(DS.bold, size: 13))
                    .foregroundColor(DS.cyan)
                Text(record.completedAt, style: .relative)
                    .font(.custom(DS.font, size: 10))
                    .foregroundColor(.white.opacity(0.30))
            }
        }
        .padding(.vertical, 4)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ViewModel
// ─────────────────────────────────────────────────────────────────────────────
@MainActor
final class ProgressDashboardViewModel: ObservableObject {
    @Published var levelsCompleted:        Int    = 0
    @Published var overallMastery:         Double = 0
    @Published var highestLevel:           Int    = 0
    @Published var aiSummary:              String = ""
    @Published var recommendedNextConcept: PhysicsConcept? = nil
    @Published var recentLevels:           [LevelRecord]   = []

    func masteryScore(for concept: PhysicsConcept) -> Double {
        ProgressTracker.shared.masteryScore(for: concept)
    }

    func refresh() {
        let t = ProgressTracker.shared
        levelsCompleted = t.totalLevelsCompleted
        overallMastery  = t.overallMastery
        highestLevel    = t.highestLevel
        aiSummary       = AICoach.shared.getPerformanceSummary()
        recentLevels    = t.recentActivity(limit: 5)
        recommendedNextConcept = PhysicsConcept.allCases.min { masteryScore(for: $0) < masteryScore(for: $1) }
    }
}

#Preview {
    NavigationStack {
        ProgressDashboardView()
    }
    .environmentObject(AppState())
    .preferredColorScheme(.dark)
}
