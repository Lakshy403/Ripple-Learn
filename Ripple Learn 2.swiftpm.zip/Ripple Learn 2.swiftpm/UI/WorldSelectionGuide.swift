import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// WorldSelectionGuide.swift
//
// Kept for backward compatibility only.
// The Levels tab now uses LevelsTabView (inline, no sheet).
// This file can be safely deleted if WorldSelectionGuide is no longer used
// anywhere as a .sheet().
// ─────────────────────────────────────────────────────────────────────────────

public struct WorldSelectionGuide: View {
    @Environment(\.dismiss) private var dismiss

    public var body: some View {
        NavigationStack {
            LevelsTabView()
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("Close") { dismiss() }
                            .foregroundColor(Color(red: 0.2, green: 0.82, blue: 1))
                    }
                }
        }
        .presentationDetents([.large])
        .presentationDragIndicator(.visible)
        .preferredColorScheme(.dark)
    }
}

#Preview {
    WorldSelectionGuide()
        .environmentObject(AppState())
        .preferredColorScheme(.dark)
}
