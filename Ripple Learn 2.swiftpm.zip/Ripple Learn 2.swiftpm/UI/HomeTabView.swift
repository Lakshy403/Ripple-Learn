import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// HomeTabView.swift  —  Tab 0: Home
// ─────────────────────────────────────────────────────────────────────────────

struct HomeTabView: View {
    var body: some View {
        NavigationStack {
            HomeContentView()
                .toolbar(.hidden, for: .navigationBar)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// HomeContentView
// ─────────────────────────────────────────────────────────────────────────────

private enum DS {
    static let bg0  = Color(red: 0.01, green: 0.05, blue: 0.10)
    static let bg1  = Color(red: 0.00, green: 0.12, blue: 0.24)
    static let cyan = Color(red: 0.20, green: 0.82, blue: 1.00)
    static let teal = Color(red: 0.00, green: 1.00, blue: 0.80)
    static let font = "AvenirNext-Medium"
    static let bold = "AvenirNext-Bold"
}

struct HomeContentView: View {
    @State private var navigateToGame: Bool    = false
    @State private var animPhase: CGFloat      = 0
    @State private var appeared                = false
    @State private var playPulse               = false
    @State private var orbRotation: Double     = 0

    var body: some View {
        ZStack {
            AnimatedWaterBackground(phase: animPhase).ignoresSafeArea()
            CausticOverlay().ignoresSafeArea()
            ShimmerLines().ignoresSafeArea()
            AmbientRipples().ignoresSafeArea()
            ParticleField().ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                TitleBlock(appeared: appeared)
                    .padding(.bottom, 48)

                // PLAY button
                NavigationLink(destination: GameView(), isActive: $navigateToGame) {
                    PlayOrb(pulse: playPulse, rotation: orbRotation)
                }
                .buttonStyle(PlainButtonStyle())
                .simultaneousGesture(
                    TapGesture().onEnded {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                            playPulse.toggle()
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                            navigateToGame = true
                        }
                    }
                )

                Spacer()

                WaveRule().padding(.bottom, 16)

                // Spacer for tab bar
                Color.clear.frame(height: 70)
            }
        }
        .onAppear {
            appeared = true
            withAnimation(.linear(duration: 14).repeatForever(autoreverses: true)) {
                animPhase = 1
            }
            withAnimation(.linear(duration: 6).repeatForever(autoreverses: false)) {
                orbRotation = 360
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// TitleBlock
// ─────────────────────────────────────────────────────────────────────────────
private struct TitleBlock: View {
    let appeared: Bool
    private let grad = LinearGradient(
        stops: [
            .init(color: .white,                                   location: 0.00),
            .init(color: Color(red: 0.78, green: 0.95, blue: 1),  location: 0.20),
            .init(color: Color(red: 0.30, green: 0.82, blue: 1),  location: 0.48),
            .init(color: Color(red: 0.00, green: 0.52, blue: 0.78), location: 0.70),
            .init(color: Color(red: 0.00, green: 0.22, blue: 0.42), location: 1.00),
        ],
        startPoint: .top, endPoint: .bottom
    )

    var body: some View {
        VStack(spacing: -4) {
            Text("RIPPLE")
                .font(.system(size: 62, weight: .black, design: .rounded))
                .tracking(8).foregroundStyle(grad)
                .shadow(color: DS.cyan.opacity(0.55), radius: 18, y: 4)
            Text("LEARN")
                .font(.system(size: 62, weight: .black, design: .rounded))
                .tracking(8).foregroundStyle(grad)
                .shadow(color: DS.cyan.opacity(0.55), radius: 18, y: 4)
            Text("MASTER PHYSICS THROUGH PLAY")
                .font(.custom(DS.font, size: 11))
                .tracking(3)
                .foregroundColor(DS.cyan.opacity(0.55))
                .padding(.top, 10)
        }
        .offset(y: appeared ? 0 : 30).opacity(appeared ? 1 : 0)
        .animation(.easeOut(duration: 0.65).delay(0.15), value: appeared)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PlayOrb
// ─────────────────────────────────────────────────────────────────────────────
private struct PlayOrb: View {
    let pulse: Bool; let rotation: Double
    private let iri: [Color] = [
        Color(red:0,green:0.83,blue:1), Color(red:0,green:1,blue:0.80),
        Color(red:0.4,green:0.71,blue:1), Color(red:0.67,green:0.40,blue:1),
        Color(red:1,green:0.40,blue:0.73), Color(red:1,green:0.67,blue:0.27),
        Color(red:0,green:1,blue:0.80), Color(red:0,green:0.83,blue:1),
    ]
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 36)
                .fill(.ultraThinMaterial)
                .overlay {
                    RoundedRectangle(cornerRadius: 36)
                        .fill(LinearGradient(
                            colors: [Color(red:0,green:0.45,blue:0.68).opacity(0.15),
                                     Color(red:0,green:0.20,blue:0.38).opacity(0.08)],
                            startPoint: .topLeading, endPoint: .bottomTrailing))
                }
                .overlay {
                    RoundedRectangle(cornerRadius: 36)
                        .stroke(AngularGradient(colors: iri, center: .center,
                                                startAngle: .degrees(rotation),
                                                endAngle: .degrees(rotation + 360)),
                                lineWidth: 1.2).opacity(0.6)
                }
                .overlay {
                    RoundedRectangle(cornerRadius: 36)
                        .fill(LinearGradient(colors: [Color.white.opacity(0.14), .clear],
                                             startPoint: .top, endPoint: .center))
                }
                .overlay { CardRippleRings() }
                .frame(width: 196, height: 196)
                .shadow(color: .black.opacity(0.55), radius: 20, y: 8)

            Circle()
                .fill(AngularGradient(colors: iri, center: .center,
                                       startAngle: .degrees(rotation),
                                       endAngle: .degrees(rotation + 360)))
                .frame(width: 128, height: 128).blur(radius: 0.5)
                .mask { Circle().stroke(lineWidth: 5).frame(width: 123, height: 123) }
                .shadow(color: DS.cyan.opacity(0.50), radius: 12)

            Circle()
                .fill(RadialGradient(stops: [
                    .init(color: Color(red:0.70,green:0.92,blue:1).opacity(0.65), location: 0),
                    .init(color: Color(red:0.20,green:0.60,blue:0.88).opacity(0.55), location: 0.28),
                    .init(color: Color(red:0.02,green:0.20,blue:0.46).opacity(0.85), location: 0.62),
                    .init(color: Color(red:0,green:0.07,blue:0.20).opacity(0.97), location: 1),
                ], center: UnitPoint(x: 0.37, y: 0.30), startRadius: 0, endRadius: 55))
                .frame(width: 114, height: 114)
                .overlay {
                    Ellipse()
                        .fill(RadialGradient(colors: [.white.opacity(0.55), .clear],
                                             center: .topLeading, startRadius: 0, endRadius: 36))
                        .frame(width: 50, height: 34).offset(x: -22, y: -24).blendMode(.screen)
                }
                .overlay {
                    Text("PLAY")
                        .font(.custom(DS.bold, size: 18)).tracking(4).foregroundColor(.white)
                        .shadow(color: DS.cyan.opacity(0.9), radius: 8)
                }
                .scaleEffect(pulse ? 1.07 : 1.0)
                .animation(.spring(response: 0.4, dampingFraction: 0.55), value: pulse)
        }
        .scaleEffect(pulse ? 1.04 : 1.0)
        .animation(.spring(response: 0.5, dampingFraction: 0.6), value: pulse)
    }
}

private struct CardRippleRings: View {
    @State private var phase: CGFloat = 0
    var body: some View {
        ZStack {
            ForEach(0..<3, id: \.self) { i in
                Circle().stroke(DS.cyan.opacity(0.12), lineWidth: 1)
                    .scaleEffect(0.3 + ((phase + CGFloat(i) / 3).truncatingRemainder(dividingBy: 1)) * 2.2)
                    .opacity((1 - (Double(phase) + Double(i) / 3).truncatingRemainder(dividingBy: 1)) * 0.7)
            }
        }
        .clipped()
        .onAppear {
            withAnimation(.linear(duration: 3).repeatForever(autoreverses: false)) { phase = 1 }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Background components (shared across tabs)
// ─────────────────────────────────────────────────────────────────────────────

struct AnimatedWaterBackground: View {
    let phase: CGFloat
    var body: some View {
        Canvas { ctx, size in
            let w = size.width, h = size.height, p = phase
            let blobs: [(CGPoint, Color, Double)] = [
                (CGPoint(x: w*(0.08+0.14*sin(p * .pi)), y: h*0.04), Color(red:0,green:0.17,blue:0.45), 0.65),
                (CGPoint(x: w*(0.88+0.07*cos(p * .pi)), y: h*0.11), Color(red:0,green:0.24,blue:0.52), 0.55),
                (CGPoint(x: w*0.04, y: h*(0.52+0.13*sin(p * .pi*0.7))), Color(red:0.01,green:0.10,blue:0.30), 0.50),
                (CGPoint(x: w*0.96, y: h*(0.46+0.10*cos(p * .pi*0.9))), Color(red:0,green:0.19,blue:0.40), 0.50),
                (CGPoint(x: w*(0.28+0.18*cos(p * .pi*1.2)), y: h*0.82), Color(red:0,green:0.11,blue:0.24), 0.60),
                (CGPoint(x: w*(0.72-0.14*sin(p * .pi*0.8)), y: h*0.90), Color(red:0.01,green:0.07,blue:0.18), 0.60),
                (CGPoint(x: w*(0.50+0.10*sin(p * .pi*0.5)), y: h*0.40), Color(red:0,green:0.22,blue:0.48), 0.30),
            ]
            for (pt, color, opacity) in blobs {
                ctx.fill(Path(CGRect(origin: .zero, size: size)),
                         with: .linearGradient(Gradient(colors: [color.opacity(opacity), .clear]),
                                               startPoint: .init(x: pt.x/w, y: pt.y/h),
                                               endPoint: .init(x: 0.5, y: 0.5)))
            }
            ctx.fill(Path(CGRect(origin: .zero, size: size)),
                     with: .color(Color(red:0.005,green:0.04,blue:0.09).opacity(0.60)))
        }
        .background(LinearGradient(colors: [DS.bg0, DS.bg1, Color(red:0,green:0.07,blue:0.16)],
                                   startPoint: .top, endPoint: .bottom))
    }
}

struct CausticOverlay: View {
    @State private var offsets: [CGSize]   = (0..<14).map { _ in CGSize(width: CGFloat.random(in:-170...170), height: CGFloat.random(in:-320...320)) }
    @State private var opacities: [Double] = (0..<14).map { _ in Double.random(in:0.03...0.10) }
    var body: some View {
        GeometryReader { geo in
            ForEach(0..<14, id: \.self) { i in
                Ellipse()
                    .fill(Color(red:0.45,green:0.88,blue:1).opacity(opacities[i]))
                    .frame(width: CGFloat.random(in:40...130), height: CGFloat.random(in:20...65))
                    .rotationEffect(.degrees(Double.random(in:-50...50)))
                    .offset(x: geo.size.width*0.5 + offsets[i].width,
                            y: geo.size.height*0.5 + offsets[i].height)
                    .blur(radius: 9)
                    .onAppear {
                        withAnimation(.easeInOut(duration: Double.random(in:6...15))
                            .repeatForever(autoreverses: true).delay(Double(i)*0.65)) {
                            offsets[i]  = CGSize(width: CGFloat.random(in:-170...170), height: CGFloat.random(in:-320...320))
                            opacities[i] = Double.random(in:0.02...0.12)
                        }
                    }
            }
        }
    }
}

struct ShimmerLines: View {
    @State private var phase: CGFloat = 0
    var body: some View {
        GeometryReader { geo in
            let w = geo.size.width
            ForEach([0.15, 0.35, 0.55, 0.75], id: \.self) { yFrac in
                Rectangle()
                    .fill(LinearGradient(colors: [.clear, DS.cyan.opacity(0.07), DS.teal.opacity(0.04), .clear],
                                         startPoint: .leading, endPoint: .trailing))
                    .frame(height: 1)
                    .offset(x: phase*w - w, y: geo.size.height*yFrac)
                    .animation(.linear(duration: Double.random(in:5...9))
                        .repeatForever(autoreverses: false).delay(Double.random(in:0...4)), value: phase)
            }
        }
        .onAppear { phase = 2 }
    }
}

struct AmbientRipples: View {
    struct Ring: Identifiable { let id: Int; let origin: CGPoint; let color: Color; let delay: Double }
    private let rings: [Ring] = [
        Ring(id:0, origin:CGPoint(x:0.28,y:0.42), color:DS.cyan, delay:0.0),
        Ring(id:1, origin:CGPoint(x:0.28,y:0.42), color:DS.cyan, delay:1.7),
        Ring(id:2, origin:CGPoint(x:0.28,y:0.42), color:DS.cyan, delay:3.4),
        Ring(id:3, origin:CGPoint(x:0.72,y:0.62), color:DS.teal, delay:0.8),
        Ring(id:4, origin:CGPoint(x:0.72,y:0.62), color:DS.teal, delay:2.5),
    ]
    var body: some View {
        GeometryReader { geo in
            ForEach(rings) { r in
                SingleRipple(cx: geo.size.width*r.origin.x,
                             cy: geo.size.height*r.origin.y,
                             color: r.color, delay: r.delay)
            }
        }
    }
}

private struct SingleRipple: View {
    let cx: CGFloat; let cy: CGFloat; let color: Color; let delay: Double
    @State private var scale: CGFloat = 1; @State private var opacity: Double = 0.55
    var body: some View {
        Circle().stroke(color.opacity(opacity), lineWidth: 1)
            .frame(width: 50, height: 50).scaleEffect(scale).position(x: cx, y: cy)
            .onAppear {
                withAnimation(.easeOut(duration: 5).repeatForever(autoreverses: false).delay(delay)) {
                    scale = 8; opacity = 0
                }
            }
    }
}

struct ParticleField: View {
    struct Mote: Identifiable {
        let id: Int; let x: CGFloat; let size: CGFloat
        let color: Color; let dur: Double; let delay: Double
    }
    private let motes: [Mote] = (0..<26).map { i in
        Mote(id: i, x: CGFloat.random(in:0...1), size: CGFloat.random(in:1.5...4),
             color: i%3==0
                ? Color(red:0,green:1,blue:0.78).opacity(Double.random(in:0.3...0.7))
                : Color(red:0,green:0.83,blue:1).opacity(Double.random(in:0.25...0.65)),
             dur: Double.random(in:6...14), delay: Double.random(in:0...10))
    }
    var body: some View {
        GeometryReader { geo in
            ForEach(motes) { m in
                FloatingMote(x: geo.size.width*m.x, h: geo.size.height,
                             size: m.size, color: m.color, dur: m.dur, delay: m.delay)
            }
        }
    }
}

private struct FloatingMote: View {
    let x: CGFloat; let h: CGFloat; let size: CGFloat
    let color: Color; let dur: Double; let delay: Double
    @State private var oy: CGFloat = 0; @State private var op: Double = 0
    var body: some View {
        Circle().fill(color).frame(width: size, height: size).blur(radius: size*0.4)
            .position(x: x + sin(oy/60)*18, y: h - oy).opacity(op)
            .onAppear {
                withAnimation(.linear(duration: dur).repeatForever(autoreverses: false).delay(delay)) { oy = h+20 }
                withAnimation(.easeIn(duration: dur*0.08).delay(delay)) { op = 1 }
                withAnimation(.easeOut(duration: dur*0.12).delay(delay + dur*0.88)) { op = 0 }
            }
    }
}

struct WaveRule: View {
    @State private var phase: CGFloat = 0
    var body: some View {
        Canvas { ctx, size in
            let w = size.width; let h = size.height/2; var path = Path()
            for x in stride(from: 0, through: w, by: 2) {
                let y = h + sin((x/w * .pi*4) - phase) * 4
                if x == 0 { path.move(to: CGPoint(x: x, y: y)) }
                else { path.addLine(to: CGPoint(x: x, y: y)) }
            }
            ctx.stroke(path, with: .color(DS.cyan.opacity(0.30)), lineWidth: 1.5)
        }
        .frame(height: 16)
        .onAppear {
            withAnimation(.linear(duration: 2.5).repeatForever(autoreverses: false)) { phase = .pi*2 }
        }
    }
}

#Preview {
    HomeTabView()
        .environmentObject(AppState())
        .preferredColorScheme(.dark)
}
