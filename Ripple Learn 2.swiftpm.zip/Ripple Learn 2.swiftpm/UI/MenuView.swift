import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// MenuView.swift  —  Backward-compatibility shim
//
// MenuView has been replaced by HomeTabView + HomeContentView.
// This typealias ensures any remaining call sites compile without changes.
// ─────────────────────────────────────────────────────────────────────────────

typealias MenuView = HomeTabView
