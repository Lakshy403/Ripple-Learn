import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// LiquidTabBar.swift  —  Floating pill tab bar (matches screenshot aesthetic)
//
// • Reads and writes AppState.selectedTab via @EnvironmentObject
// • Compact pill/capsule shape with frosted glass
// • Active tab has a filled rounded-square highlight
// ─────────────────────────────────────────────────────────────────────────────

struct LiquidTabBar: View {
    @EnvironmentObject private var appState: AppState

    private let tabs: [(icon: String, label: String, activeColor: Color)] = [
        ("square.grid.2x2.fill", "Home",     Color(red: 0.20, green: 0.82, blue: 1.00)),
        ("leaf.fill",            "Levels",   Color(red: 0.20, green: 0.82, blue: 1.00)),
        ("waveform",             "Progress", Color(red: 0.20, green: 0.82, blue: 1.00)),
    ]

    var body: some View {
        HStack(spacing: 6) {
            ForEach(tabs.indices, id: \.self) { i in
                tabButton(i)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(
            Capsule()
                .fill(.ultraThinMaterial)
                .overlay(
                    Capsule()
                        .fill(Color(red: 0.08, green: 0.14, blue: 0.26).opacity(0.55))
                )
                .overlay(
                    Capsule()
                        .stroke(Color.white.opacity(0.12), lineWidth: 1)
                )
        )
        .shadow(color: .black.opacity(0.50), radius: 24, y: 8)
        .shadow(color: Color(red: 0.20, green: 0.82, blue: 1.00).opacity(0.08), radius: 16, y: 4)
    }

    @ViewBuilder
    private func tabButton(_ i: Int) -> some View {
        let active = appState.selectedTab == i
        let tab = tabs[i]

        Button {
            withAnimation(.spring(response: 0.30, dampingFraction: 0.70)) {
                appState.selectedTab = i
            }
        } label: {
            ZStack {
                // Active filled square background
                if active {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(
                            LinearGradient(
                                colors: [
                                    tab.activeColor.opacity(0.85),
                                    tab.activeColor.opacity(0.55)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(
                                    LinearGradient(
                                        colors: [Color.white.opacity(0.25), .clear],
                                        startPoint: .top,
                                        endPoint: .center
                                    )
                                )
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.white.opacity(0.20), lineWidth: 0.5)
                        )
                        .shadow(color: tab.activeColor.opacity(0.60), radius: 10, y: 2)
                        .transition(.scale(scale: 0.7).combined(with: .opacity))
                }

                Image(systemName: tab.icon)
                    .font(.system(size: 18, weight: active ? .semibold : .regular))
                    .foregroundColor(
                        active
                            ? .white
                            : Color.white.opacity(0.35)
                    )
                    .shadow(
                        color: active ? tab.activeColor.opacity(0.9) : .clear,
                        radius: 6
                    )
                    .scaleEffect(active ? 1.05 : 1.0)
                    .animation(
                        .spring(response: 0.35, dampingFraction: 0.65),
                        value: active
                    )
            }
            .frame(width: 46, height: 46)
        }
        .buttonStyle(TabPressStyle())
    }
}

// Subtle press scale for tap feedback
private struct TabPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.88 : 1.0)
            .animation(.easeOut(duration: 0.10), value: configuration.isPressed)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ContentView — updated to position the pill tab bar at screen bottom center
// ─────────────────────────────────────────────────────────────────────────────

