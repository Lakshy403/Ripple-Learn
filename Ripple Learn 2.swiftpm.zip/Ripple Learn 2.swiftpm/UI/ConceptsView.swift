import SwiftUI
import Charts

private enum DS {
    static let bg0  = Color(red: 0.01, green: 0.05, blue: 0.12)
    static let bg1  = Color(red: 0.00, green: 0.12, blue: 0.24)
    static let cyan = Color(red: 0.20, green: 0.82, blue: 1.00)
    static let font = "AvenirNext-Medium"
    static let bold = "AvenirNext-Bold"
    static let demi = "AvenirNext-DemiBold"
}

extension PhysicsConcept {
    var worldInfo: WorldInfo {
        allWorldsData.first { $0.concept == self } ?? allWorldsData[0]
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ConceptsView
// ─────────────────────────────────────────────────────────────────────────────
struct ConceptsView: View {
    let concepts = ConceptLibrary.shared.getAllConcepts()

    private func physicsConcept(for concept: Concept) -> PhysicsConcept {
        PhysicsConcept.allCases.first { $0.rawValue == concept.id } ?? .wavePropagation
    }

    var body: some View {
        ZStack {
            LinearGradient(colors: [DS.bg0, DS.bg1], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            CausticOverlay().ignoresSafeArea().opacity(0.35)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {

                    VStack(alignment: .leading, spacing: 6) {
                        Text("Physics Concepts")
                            .font(.system(size: 28, weight: .black, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(colors: [.white, DS.cyan],
                                               startPoint: .leading, endPoint: .trailing)
                            )
                        Text("Tap any concept to explore the physics behind the game")
                            .font(.custom(DS.font, size: 14))
                            .foregroundColor(.white.opacity(0.55))
                    }
                    .padding(.top, 8)

                    ForEach(Array(concepts.enumerated()), id: \.element.id) { idx, concept in
                        let pc = physicsConcept(for: concept)
                        NavigationLink {
                            ConceptDetailView(world: pc.worldInfo)
                        } label: {
                            ConceptCard(concept: concept, physicsConcept: pc, delay: Double(idx) * 0.07)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }

                    Spacer(minLength: 90)
                }
                .padding(.horizontal, 18)
                .padding(.top, 20)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        // ── Tab bar — disappears naturally when ConceptDetailView/GameView is pushed ──
        .safeAreaInset(edge: .bottom, spacing: 0) {
            LiquidTabBar()
                .padding(.bottom, 28)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ConceptCard
// ─────────────────────────────────────────────────────────────────────────────
struct ConceptCard: View {
    let concept: Concept
    let physicsConcept: PhysicsConcept
    let delay: Double
    @State private var appeared = false

    var body: some View {
        HStack(spacing: 0) {
            Rectangle()
                .fill(LinearGradient(
                    colors: [physicsConcept.accentColor, physicsConcept.accentColor.opacity(0.3)],
                    startPoint: .top, endPoint: .bottom))
                .frame(width: 4)
                .clipShape(RoundedCornerShape(corners: [.topLeft, .bottomLeft], radius: 16))

            HStack(spacing: 14) {
                Text(physicsConcept.emoji)
                    .font(.system(size: 38))
                    .frame(width: 52)

                VStack(alignment: .leading, spacing: 5) {
                    Text(concept.title)
                        .font(.custom(DS.font, size: 11))
                        .foregroundColor(physicsConcept.accentColor.opacity(0.9))
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(Capsule().fill(physicsConcept.accentColor.opacity(0.15)))

                    Text(concept.title)
                        .font(.custom(DS.bold, size: 18))
                        .foregroundColor(.white)

                    if !concept.description.isEmpty {
                        Text(concept.description)
                            .font(.custom(DS.font, size: 12))
                            .foregroundColor(.white.opacity(0.55))
                            .lineLimit(2)
                    }
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(physicsConcept.accentColor.opacity(0.7))
            }
            .padding(.horizontal, 16).padding(.vertical, 16)
        }
        .background(ZStack {
            RoundedRectangle(cornerRadius: 16).fill(.ultraThinMaterial)
            RoundedRectangle(cornerRadius: 16).fill(physicsConcept.accentColor.opacity(0.04))
            RoundedRectangle(cornerRadius: 16).stroke(physicsConcept.accentColor.opacity(0.22), lineWidth: 1)
        })
        .shadow(color: physicsConcept.accentColor.opacity(0.15), radius: 12, y: 4)
        .offset(x: appeared ? 0 : -30)
        .opacity(appeared ? 1 : 0)
        .onAppear {
            withAnimation(.easeOut(duration: 0.45).delay(delay)) { appeared = true }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// WaveChart
// ─────────────────────────────────────────────────────────────────────────────
struct WaveChart: View {
    let concept: PhysicsConcept
    @State private var animate = false

    private func waveData() -> [(x: Double, y: Double)] {
        (0...60).map { i in
            let x = Double(i) / 60.0
            let y: Double
            switch concept {
            case .wavePropagation: y = sin(x * .pi * 4) * exp(-x * 1.5)
            case .reflection:      y = abs(sin(x * .pi * 3))
            case .interference:    y = sin(x * .pi * 6) + 0.4 * sin(x * .pi * 10)
            case .refraction:      y = x < 0.5 ? sin(x * .pi * 5) * 0.6 : sin(x * .pi * 8)
            case .resonance:       y = sin(x * .pi * 4) * (animate ? x * 1.2 : x)
            case .complexSystems:  y = sin(x * .pi * 5) * cos(x * .pi * 3) + 0.3 * sin(x * .pi * 11)
            }
            return (x: x, y: y)
        }
    }

    var body: some View {
        Chart {
            ForEach(waveData(), id: \.x) { point in
                LineMark(x: .value("Position", point.x), y: .value("Amplitude", point.y))
                    .foregroundStyle(concept.accentColor.gradient)
                    .interpolationMethod(.catmullRom)
                AreaMark(x: .value("Position", point.x), yStart: .value("Zero", 0), yEnd: .value("Amplitude", point.y))
                    .foregroundStyle(concept.accentColor.opacity(0.12).gradient)
                    .interpolationMethod(.catmullRom)
            }
        }
        .chartXAxis(.hidden).chartYAxis(.hidden)
        .chartYScale(domain: -1.5...1.5)
        .onAppear {
            withAnimation(.easeInOut(duration: 1.8).repeatForever(autoreverses: true)) { animate = true }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ConceptSection
// ─────────────────────────────────────────────────────────────────────────────
struct ConceptSection: View {
    let icon: String; let title: String; let text: String; let accent: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: icon).font(.system(size: 12, weight: .semibold)).foregroundColor(accent)
                Text(title).font(.custom(DS.demi, size: 13)).foregroundColor(accent)
            }
            Text(text)
                .font(.custom(DS.font, size: 13))
                .foregroundColor(.white.opacity(0.82))
                .lineSpacing(4)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 16).padding(.top, 14)
    }
}

struct ConceptCardPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}
