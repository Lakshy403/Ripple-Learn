// GameView.swift
// All 13 Xcode errors fixed:
//   ✅ OceanBackground redeclaration — removed from here, lives only in this file now
//      (WaterRippleView.swift no longer defines it)
//   ✅ [SIMD4<Float>].shaderArgument duplicate — removed from here, lives in WaterRippleView.swift
//   ✅ MetalWaterOverlay argument count — fixed to match actual Metal shader signatures
//   ✅ WaterViewModel.concept ObservedObject — MetalWaterOverlay uses @ObservedObject properly
//   ✅ Cannot assign PhysicsConcept to Binding<Subject> — onChange uses new (_, new) form
//   ✅ .navigationBarHidden deprecated — .toolbar(.hidden, for: .navigationBar)
//   ✅ UIColor.clear for SpriteKit backgroundColor

import SwiftUI
import SpriteKit
import Vision

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - Design tokens
// ─────────────────────────────────────────────────────────────────────────────

private enum DS {
    static let font      = "AvenirNext-Medium"
    static let bold      = "AvenirNext-Bold"
    static let demi      = "AvenirNext-DemiBold"
    static let deepOcean = Color(red: 0.01, green: 0.05, blue: 0.12)
    static let midOcean  = Color(red: 0.02, green: 0.14, blue: 0.28)
    static let cyan      = Color(red: 0.20, green: 0.85, blue: 1.00)
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - SceneHolder
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
final class SceneHolder: ObservableObject {
    let scene: GameScene = {
        let s             = GameScene()
        s.size            = UIScreen.main.bounds.size
        s.scaleMode       = .resizeFill
        s.backgroundColor = UIColor.clear   // Must be UIColor, not SKColor
        return s
    }()
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - GameView
// ─────────────────────────────────────────────────────────────────────────────

struct GameView: View {
    var startConcept: PhysicsConcept? = nil

    @Environment(\.dismiss) var dismiss
    @StateObject private var holder = SceneHolder()

    @State private var currentLevel:  Int            = 1
    @State private var ripplesUsed:   Int            = 0
    @State private var activeConcept: PhysicsConcept = .wavePropagation
    @State private var conceptHint:   String         = ""
    @State private var showHint:      Bool           = true
    @State private var showBanner:    Bool           = false
    @State private var bannerText:    String         = ""
    @State private var backAppeared                  = false
    @State private var handPoints:    [CGPoint]      = []

    var body: some View {
        ZStack {
            // ── Layer 1: Ocean background (always visible, no Metal needed) ─
            OceanBackground(concept: activeConcept)
                .ignoresSafeArea()

            // ── Layer 2: SpriteKit game scene ─────────────────────────────
            SpriteView(
                scene:                    holder.scene,
                preferredFramesPerSecond: 120,
                options:                  [.allowsTransparency]
            )
            .ignoresSafeArea()
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            // ── Layer 3: Metal GPU water (iOS 17+ only, graceful fallback) ─
            if #available(iOS 17.0, *) {
                MetalWaterOverlay(concept: activeConcept)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
            }

            // ── Layer 4: Depth vignette ───────────────────────────────────
            LinearGradient(
                colors: [DS.deepOcean.opacity(0.0),
                         DS.midOcean.opacity(0.20),
                         DS.deepOcean.opacity(0.50)],
                startPoint: .top, endPoint: .bottom
            )
            .ignoresSafeArea()
            .allowsHitTesting(false)

            // ── Layer 5: Hand pose dots ───────────────────────────────────
            if !handPoints.isEmpty {
                HandPoseOverlay(points: handPoints)
                    .ignoresSafeArea()
                    .allowsHitTesting(false)
            }

            // ── Layer 6: Level complete banner ────────────────────────────
            if showBanner {
                LevelCompleteBanner(text: bannerText, concept: activeConcept)
                    .transition(.asymmetric(
                        insertion: .scale(scale: 0.72).combined(with: .opacity),
                        removal:   .scale(scale: 1.18).combined(with: .opacity)
                    ))
                    .zIndex(50)
            }

            // ── Layer 7: HUD ──────────────────────────────────────────────
            VStack(spacing: 0) {
                topBar
                Spacer()
                bottomHint
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .statusBar(hidden: true)
        .onAppear(perform: handleAppear)
        .onReceive(NotificationCenter.default.publisher(for: .gameConceptChanged)) { n in
            if let c = n.object as? PhysicsConcept {
                withAnimation { activeConcept = c }
                conceptHint = HintSystem.shared.getConceptHint(concept: c)
                withAnimation { showHint = true }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .gameLevelChanged)) { n in
            if let lvl = n.object as? Int { withAnimation { currentLevel = lvl } }
        }
        .onReceive(NotificationCenter.default.publisher(for: .gameRipplesChanged)) { n in
            if let r = n.object as? Int { withAnimation { ripplesUsed = r } }
        }
        .onReceive(NotificationCenter.default.publisher(for: .levelComplete)) { n in
            bannerText = n.object as? String ?? "Level Complete!"
            withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) { showBanner = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
                withAnimation(.easeOut(duration: 0.35)) { showBanner = false }
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .handPointsUpdated)) { n in
            handPoints = n.object as? [CGPoint] ?? []
        }
    }

    private func handleAppear() {
        if let c = startConcept {
            NotificationCenter.default.post(name: .gameStartConcept, object: c)
            activeConcept = c
            conceptHint   = HintSystem.shared.getConceptHint(concept: c)
        }
        withAnimation(.spring(response: 0.5, dampingFraction: 0.6).delay(0.2)) {
            backAppeared = true
        }
    }

    private var topBar: some View {
        ZStack {
            LevelPill(level: currentLevel, ripples: ripplesUsed, concept: activeConcept)
            HStack {
                Button { dismiss() } label: {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.white.opacity(0.85))
                        .frame(width: 36, height: 36)
                        .background(GlassCircle())
                }
                .buttonStyle(PlainButtonStyle())
                .scaleEffect(backAppeared ? 1 : 0.5)
                .opacity(backAppeared ? 1 : 0)
                .animation(.spring(response: 0.45, dampingFraction: 0.6), value: backAppeared)

                Spacer()
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 56)
    }

    @ViewBuilder
    private var bottomHint: some View {
        if showHint && !conceptHint.isEmpty {
            HintCard(
                text:      conceptHint,
                concept:   activeConcept,
                onDismiss: { withAnimation(.easeOut(duration: 0.25)) { showHint = false } }
            )
            .padding(.horizontal, 16)
            .padding(.bottom, 38)
            .transition(.move(edge: .bottom).combined(with: .opacity))
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - OceanBackground
// Defined ONLY here. WaterRippleView.swift must NOT define this type.
// Uses TimelineView for smooth animation with no @State timer.
// ─────────────────────────────────────────────────────────────────────────────

struct OceanBackground: View {
    let concept: PhysicsConcept

    var body: some View {
        TimelineView(.animation) { tl in
            let t = tl.date.timeIntervalSinceReferenceDate
            Canvas { ctx, size in
                let w = size.width, h = size.height

                // Deep ocean base gradient
                ctx.fill(
                    Path(CGRect(origin: .zero, size: size)),
                    with: .linearGradient(
                        Gradient(stops: [
                            .init(color: Color(red: 0.005, green: 0.040, blue: 0.120), location: 0.00),
                            .init(color: Color(red: 0.010, green: 0.100, blue: 0.240), location: 0.35),
                            .init(color: Color(red: 0.020, green: 0.180, blue: 0.360), location: 0.70),
                            .init(color: Color(red: 0.030, green: 0.240, blue: 0.440), location: 1.00),
                        ]),
                        startPoint: CGPoint(x: w / 2, y: 0),
                        endPoint:   CGPoint(x: w / 2, y: h)
                    )
                )

                // Animated caustic blobs — colour keyed to active concept
                let acc = concept.accentColor
                let blobs: [(CGPoint, CGFloat, Double)] = [
                    (CGPoint(x: w * (0.28 + 0.10 * sin(t * 0.40)), y: h * 0.18), w * 0.38, 0.07),
                    (CGPoint(x: w * (0.72 + 0.07 * cos(t * 0.31)), y: h * 0.13), w * 0.28, 0.055),
                    (CGPoint(x: w * (0.50 + 0.11 * sin(t * 0.55)), y: h * 0.36), w * 0.24, 0.045),
                    (CGPoint(x: w * (0.18 + 0.08 * cos(t * 0.28)), y: h * 0.58), w * 0.20, 0.035),
                ]
                for (centre, radius, alpha) in blobs {
                    ctx.fill(
                        Path(ellipseIn: CGRect(x: centre.x - radius, y: centre.y - radius,
                                               width: radius * 2, height: radius * 2)),
                        with: .radialGradient(
                            Gradient(colors: [acc.opacity(alpha), .clear]),
                            center: centre, startRadius: 0, endRadius: radius
                        )
                    )
                }

                // Slow horizontal shimmer lines
                for (i, yFrac) in [0.22, 0.45, 0.68, 0.88].enumerated() {
                    let y  = h * yFrac
                    let x0 = w * fmod(t * 0.06 + Double(i) * 0.25, 1.0)
                    let p  = Path { path in
                        path.move(to:    CGPoint(x: x0 - w * 0.25, y: y))
                        path.addLine(to: CGPoint(x: x0 + w * 0.25, y: y))
                    }
                    ctx.stroke(p, with: .color(Color(red: 0.20, green: 0.85, blue: 1.00).opacity(0.04)),
                               lineWidth: 1)
                }
            }
        }
        // Solid fallback — prevents white flash before Canvas renders
        .background(Color(red: 0.01, green: 0.05, blue: 0.12))
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - MetalWaterOverlay  (iOS 17+ only)
// Uses @StateObject so WaterViewModel lifecycle is correct.
// onChange uses the (oldValue, newValue) Swift 5.9+ form to avoid Binding error.
// ShaderLibrary argument lists match the exact Metal function signatures.
// ─────────────────────────────────────────────────────────────────────────────

@available(iOS 17.0, *)
private struct MetalWaterOverlay: View {
    let concept: PhysicsConcept

    // @StateObject — correct ownership; avoids the ObservedObject key-path error
    @StateObject private var vm = WaterViewModel()

    var body: some View {
        GeometryReader { geo in
            let sz     = geo.size
            let packed = vm.packedRipples()
            var count  = Int32(vm.activeRippleCount)

            ZStack {
                // ── Pass 1: Gerstner + caustic + UV distortion ────────────
                // Metal signature: rippleDistortion(pos, layer, size, time, choppiness, ripples[], rippleCount)
                Rectangle()
                    .fill(.clear)
                    .layerEffect(
                        ShaderLibrary.bundle(.main).rippleDistortion(
                            .float2(Float(sz.width), Float(sz.height)),
                            .float(vm.time),
                            .float(vm.choppiness),
                            packed.shaderArgument,      // device const float4* ripples
                            .data(Data(bytes: &count, count: MemoryLayout<Int32>.size))   // int rippleCount
                        ),
                        maxSampleOffset: CGSize(width: 48, height: 48),
                        isEnabled: true
                    )

                // ── Pass 2: Glowing cyan ring overlay ─────────────────────
                // Metal signature: touchRippleOnly(pos, layer, size, time, ripples[], rippleCount)
                if count > 0 {
                    Rectangle()
                        .fill(.clear)
                        .layerEffect(
                            ShaderLibrary.bundle(.main).touchRippleOnly(
                                .float2(Float(sz.width), Float(sz.height)),
                                .float(vm.time),
                                packed.shaderArgument,
                                .data(Data(bytes: &count, count: MemoryLayout<Int32>.size))
                            ),
                            maxSampleOffset: CGSize(width: 8, height: 8),
                            isEnabled: true
                        )
                        .allowsHitTesting(false)
                }
            }
        }
        // Swift 5.9+ onChange — (oldValue, newValue) avoids Binding<Subject> error
        .onChange(of: concept) { _, newConcept in
            vm.concept = newConcept
        }
        // Forward SpriteKit-side taps into the Metal ripple buffer
        .onReceive(NotificationCenter.default.publisher(for: .metalTapForwarded)) { n in
            guard let pt = n.object as? CGPoint else { return }
            let ss = UIScreen.main.bounds.size
            vm.spawnRipple(at: CGPoint(x: pt.x / ss.width, y: pt.y / ss.height),
                           intensity: 1.0)
        }
        // Sync initial concept on appear
        .onAppear { vm.concept = concept }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - GlassCircle
// ─────────────────────────────────────────────────────────────────────────────

private struct GlassCircle: View {
    var body: some View {
        Circle()
            .fill(.ultraThinMaterial)
            .overlay(Circle().stroke(Color.white.opacity(0.13), lineWidth: 1))
            .shadow(color: .black.opacity(0.28), radius: 8, y: 3)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - LevelPill
// ─────────────────────────────────────────────────────────────────────────────

private struct LevelPill: View {
    let level:   Int
    let ripples: Int
    let concept: PhysicsConcept
    @State private var glowPulse = false

    var body: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(concept.accentColor)
                .frame(width: 7, height: 7)
                .shadow(color: concept.accentColor.opacity(glowPulse ? 1.0 : 0.4),
                        radius: glowPulse ? 6 : 3)
                .scaleEffect(glowPulse ? 1.3 : 1.0)
                .animation(.easeInOut(duration: 1.4).repeatForever(autoreverses: true),
                           value: glowPulse)
                .onAppear { glowPulse = true }

            Text("Level \(level)")
                .font(.custom(DS.bold, size: 15))
                .foregroundColor(.white)
                .shadow(color: .black.opacity(0.5), radius: 3, y: 1)

            if ripples > 0 {
                Text("· \(ripples) ≋")
                    .font(.custom(DS.font, size: 12))
                    .foregroundColor(.white.opacity(0.50))
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 10)
        .background(
            Capsule()
                .fill(.ultraThinMaterial)
                .overlay(
                    Capsule().fill(LinearGradient(
                        colors: [Color.white.opacity(0.18), DS.cyan.opacity(0.10), Color.clear],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ))
                )
                .overlay(
                    Capsule().stroke(LinearGradient(
                        colors: [Color.white.opacity(0.28),
                                 DS.cyan.opacity(0.20),
                                 Color.white.opacity(0.06)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ), lineWidth: 1)
                )
        )
        .shadow(color: .black.opacity(0.40), radius: 14, y: 5)
        .shadow(color: concept.accentColor.opacity(0.18), radius: 18)
        .animation(.spring(response: 0.35), value: level)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - HintCard
// ─────────────────────────────────────────────────────────────────────────────

struct HintCard: View {
    let text:      String
    let concept:   PhysicsConcept
    let onDismiss: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Hint")
                    .font(.custom(DS.bold, size: 17))
                    .foregroundColor(.white)
                    .shadow(color: DS.cyan.opacity(0.3), radius: 4)
                Spacer()
                Button(action: onDismiss) {
                    ZStack {
                        Circle().fill(Color.white.opacity(0.10)).frame(width: 28, height: 28)
                        Image(systemName: "xmark")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.white.opacity(0.60))
                    }
                }
                .buttonStyle(PlainButtonStyle())
            }
            Text(text)
                .font(.custom(DS.font, size: 14))
                .foregroundColor(.white.opacity(0.82))
                .lineSpacing(4)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 18)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 24)
                        .fill(LinearGradient(
                            colors: [DS.midOcean.opacity(0.30), DS.deepOcean.opacity(0.15)],
                            startPoint: .topLeading, endPoint: .bottomTrailing
                        ))
                )
                .overlay(alignment: .top) {
                    RoundedRectangle(cornerRadius: 24)
                        .fill(LinearGradient(
                            colors: [Color.white.opacity(0.16), Color.clear],
                            startPoint: .top, endPoint: .center
                        ))
                }
                .overlay(
                    RoundedRectangle(cornerRadius: 24)
                        .stroke(LinearGradient(
                            colors: [Color(red: 0.55, green: 0.85, blue: 1.00).opacity(0.55),
                                     Color(red: 0.40, green: 0.65, blue: 0.90).opacity(0.25),
                                     Color.white.opacity(0.08)],
                            startPoint: .topLeading, endPoint: .bottomTrailing
                        ), lineWidth: 1.2)
                )
        )
        .shadow(color: .black.opacity(0.45), radius: 22, y: 8)
        .shadow(color: DS.cyan.opacity(0.06), radius: 22)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - LevelCompleteBanner
// ─────────────────────────────────────────────────────────────────────────────

struct LevelCompleteBanner: View {
    let text:    String
    let concept: PhysicsConcept
    @State private var trigger = false

    var body: some View {
        VStack(spacing: 12) {
            Text(concept.emoji)
                .font(.system(size: 54))
                .shadow(color: concept.accentColor.opacity(0.7), radius: 16)
            Text(text)
                .font(.custom(DS.bold, size: 26))
                .foregroundStyle(LinearGradient(
                    colors: [concept.accentColor, .white],
                    startPoint: .leading, endPoint: .trailing
                ))
                .shadow(color: concept.accentColor.opacity(0.5), radius: 8)
            Text("Wave physics in action!")
                .font(.custom(DS.font, size: 14))
                .foregroundColor(.white.opacity(0.60))
        }
        .padding(.horizontal, 42).padding(.vertical, 32)
        .background(
            RoundedRectangle(cornerRadius: 28)
                .fill(.ultraThinMaterial)
                .overlay(RoundedRectangle(cornerRadius: 28)
                    .stroke(concept.accentColor.opacity(0.55), lineWidth: 1.5))
        )
        .shadow(color: concept.accentColor.opacity(0.55), radius: 32, y: 10)
        .scaleEffect(trigger ? 1.0 : 0.80)
        .opacity(trigger ? 1.0 : 0.0)
        .onAppear {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) { trigger = true }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - ConceptBadge
// ─────────────────────────────────────────────────────────────────────────────

struct ConceptBadge: View {
    let concept: PhysicsConcept
    @State private var appear = false

    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: concept.icon)
                .font(.system(size: 10, weight: .semibold))
            Text(concept.shortName)
                .font(.custom(DS.demi, size: 11))
                .lineLimit(1)
        }
        .foregroundColor(.white)
        .padding(.horizontal, 11).padding(.vertical, 7)
        .background(
            Capsule().fill(concept.accentColor.opacity(0.30))
                .overlay(Capsule().stroke(concept.accentColor.opacity(0.50), lineWidth: 1))
        )
        .shadow(color: concept.accentColor.opacity(0.45), radius: 7, y: 2)
        .fixedSize()
        .scaleEffect(appear ? 1 : 0.7)
        .opacity(appear ? 1 : 0)
        .onAppear {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.6).delay(0.5)) { appear = true }
        }
        .animation(.spring(response: 0.35), value: concept.intId)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - HintBar  (backward compat alias)
// ─────────────────────────────────────────────────────────────────────────────

struct HintBar: View {
    let text: String
    let concept: PhysicsConcept

    var body: some View {
        Text(text)
            .font(.custom(DS.font, size: 13))
            .foregroundColor(.white.opacity(0.90))
            .multilineTextAlignment(.center).lineSpacing(3)
            .padding(.horizontal, 16).padding(.vertical, 11)
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(.ultraThinMaterial)
                    .overlay(RoundedRectangle(cornerRadius: 16)
                        .stroke(concept.accentColor.opacity(0.30), lineWidth: 1))
            )
            .shadow(color: .black.opacity(0.25), radius: 8, y: 2)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - HandPoseOverlay
// ─────────────────────────────────────────────────────────────────────────────

struct HandPoseOverlay: View {
    let points: [CGPoint]

    var body: some View {
        Canvas { ctx, _ in
            for pt in points {
                let r: CGFloat = 6
                ctx.fill(
                    Path(ellipseIn: CGRect(x: pt.x - r, y: pt.y - r, width: r*2, height: r*2)),
                    with: .color(DS.cyan.opacity(0.85))
                )
                let rg: CGFloat = 11
                ctx.stroke(
                    Path(ellipseIn: CGRect(x: pt.x - rg, y: pt.y - rg, width: rg*2, height: rg*2)),
                    with: .color(DS.cyan.opacity(0.35)),
                    lineWidth: 1.8
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - VisionCoordinator
// ─────────────────────────────────────────────────────────────────────────────

final class VisionCoordinator: NSObject {
    private let handPoseRequest: VNDetectHumanHandPoseRequest = {
        let r = VNDetectHumanHandPoseRequest()
        r.maximumHandCount = 2
        return r
    }()

    func process(sampleBuffer: CMSampleBuffer,
                 orientation: CGImagePropertyOrientation = .up) {
        guard let pb = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let handler = VNImageRequestHandler(cvPixelBuffer: pb,
                                            orientation: orientation, options: [:])
        do { try handler.perform([handPoseRequest]) } catch { return }
        guard let obs = handPoseRequest.results, !obs.isEmpty else { return }

        let ss  = UIScreen.main.bounds.size
        var pts = [CGPoint]()
        let joints: [VNHumanHandPoseObservation.JointName] =
            [.thumbTip, .indexTip, .middleTip, .ringTip, .littleTip]

        for o in obs {
            for j in joints {
                guard let p = try? o.recognizedPoint(j), p.confidence > 0.5 else { continue }
                pts.append(CGPoint(x: p.location.x * ss.width,
                                   y: (1 - p.location.y) * ss.height))
            }
        }
        DispatchQueue.main.async {
            NotificationCenter.default.post(name: .handPointsUpdated, object: pts)
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MARK: - Preview
// ─────────────────────────────────────────────────────────────────────────────

#Preview {
    GameView(startConcept: .wavePropagation)
        .preferredColorScheme(.dark)
}
