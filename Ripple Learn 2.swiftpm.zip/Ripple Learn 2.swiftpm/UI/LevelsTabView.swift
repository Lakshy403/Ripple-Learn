//
//  LevelsTabView.swift
//  Ripple Learn
//
//  Created by user@51 on 28/02/26.
//

import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// LevelsTabView.swift  —  Tab 1: Levels
//
// Full-screen inline tab page — NO sheet, NO dismiss.
// NavigationLinks push to ConceptDetailView within the NavigationStack
// that ContentView provides for this tab.
// ─────────────────────────────────────────────────────────────────────────────

private enum LDS {
    static let bg0  = Color(red: 0.01, green: 0.05, blue: 0.12)
    static let bg1  = Color(red: 0.00, green: 0.12, blue: 0.24)
    static let cyan = Color(red: 0.20, green: 0.82, blue: 1.00)
    static let font = "AvenirNext-Medium"
    static let bold = "AvenirNext-Bold"
}

struct LevelsTabView: View {
    var body: some View {
        ZStack {
            // Background
            LinearGradient(
                colors: [LDS.bg0, LDS.bg1],
                startPoint: .topLeading,
                endPoint:   .bottomTrailing
            )
            .ignoresSafeArea()

            CausticOverlay().ignoresSafeArea().opacity(0.35)

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {

                    // Header
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Select World")
                            .font(.system(size: 28, weight: .black, design: .rounded))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [.white, LDS.cyan],
                                    startPoint: .leading, endPoint: .trailing
                                )
                            )
                        Text("Each world teaches a different physics concept")
                            .font(.custom(LDS.font, size: 14))
                            .foregroundColor(.white.opacity(0.55))
                    }
                    .padding(.top, 8)

                    // World cards with NavigationLinks
                    ForEach(Array(allWorldsData.enumerated()), id: \.element.id) { idx, world in
                        NavigationLink {
                            ConceptDetailView(world: world)
                        } label: {
                            WorldCard2(
                                world: world,
                                description: worldDesc(world.concept),
                                delay: Double(idx) * 0.07
                            ) {}
                        }
                        .buttonStyle(PlainButtonStyle())
                    }

                    // Space for tab bar
                    Spacer(minLength: 90)
                }
                .padding(.horizontal, 18)
                .padding(.top, 20)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private func worldDesc(_ c: PhysicsConcept) -> String {
        switch c {
        case .wavePropagation: return "Learn how energy travels through water as expanding circular waves"
        case .reflection:      return "Bounce waves off walls to redirect the flower to the goal"
        case .interference:    return "Combine multiple waves for powerful constructive interference"
        case .refraction:      return "Guide waves through shallow and deep zones to bend their path"
        case .resonance:       return "Build wave energy by tapping in rhythm with the natural frequency"
        case .complexSystems:  return "Master all physics concepts together in challenging puzzles"
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// World data — single declaration, used by both tabs
// ─────────────────────────────────────────────────────────────────────────────

struct WorldInfo: Identifiable {
    let id: Int; let number: Int; let title: String; let icon: String
    let levels: ClosedRange<Int>; let concept: PhysicsConcept; let accentColor: Color
}

let allWorldsData: [WorldInfo] = [
    WorldInfo(id:1,number:1,title:"Wave Basics",    icon:"🌊",levels:1...5,   concept:.wavePropagation,accentColor:Color(red:0.10,green:0.72,blue:1.00)),
    WorldInfo(id:2,number:2,title:"Reflection",     icon:"🪞",levels:6...10,  concept:.reflection,     accentColor:Color(red:0.65,green:0.78,blue:1.00)),
    WorldInfo(id:3,number:3,title:"Interference",   icon:"🌀",levels:11...15, concept:.interference,   accentColor:Color(red:0.55,green:0.28,blue:1.00)),
    WorldInfo(id:4,number:4,title:"Refraction",     icon:"🌈",levels:16...20, concept:.refraction,     accentColor:Color(red:0.15,green:0.90,blue:0.75)),
    WorldInfo(id:5,number:5,title:"Resonance",      icon:"🔊",levels:21...25, concept:.resonance,      accentColor:Color(red:1.00,green:0.55,blue:0.22)),
    WorldInfo(id:6,number:6,title:"Complex Systems",icon:"🌪️",levels:26...30, concept:.complexSystems, accentColor:Color(red:1.00,green:0.25,blue:0.72)),
]

// ─────────────────────────────────────────────────────────────────────────────
// WorldCard2
// ─────────────────────────────────────────────────────────────────────────────

struct WorldCard2: View {
    let world: WorldInfo; let description: String; let delay: Double; let onTap: () -> Void
    @State private var appeared = false

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 0) {
                Rectangle()
                    .fill(LinearGradient(colors:[world.accentColor,world.accentColor.opacity(0.3)],startPoint:.top,endPoint:.bottom))
                    .frame(width:4)
                    .clipShape(RoundedCornerShape(corners:[.topLeft,.bottomLeft],radius:16))

                HStack(spacing:14) {
                    Text(world.icon).font(.system(size:38)).frame(width:52)
                    VStack(alignment:.leading,spacing:5) {
                        HStack(spacing:8) {
                            Text("World \(world.number)").font(.custom(LDS.font,size:11))
                                .foregroundColor(world.accentColor.opacity(0.9))
                                .padding(.horizontal,8).padding(.vertical,3)
                                .background(Capsule().fill(world.accentColor.opacity(0.15)))
                            Text("Levels \(world.levels.lowerBound)–\(world.levels.upperBound)")
                                .font(.custom(LDS.font,size:11)).foregroundColor(.white.opacity(0.4))
                        }
                        Text(world.title).font(.custom(LDS.bold,size:18)).foregroundColor(.white)
                        if !description.isEmpty {
                            Text(description).font(.custom(LDS.font,size:12))
                                .foregroundColor(.white.opacity(0.55)).lineLimit(2)
                        }
                    }
                    Spacer()
                    Image(systemName:"chevron.right")
                        .font(.system(size:13,weight:.semibold))
                        .foregroundColor(world.accentColor.opacity(0.7))
                }
                .padding(.horizontal,16).padding(.vertical,16)
            }
            .background(ZStack {
                RoundedRectangle(cornerRadius:16).fill(.ultraThinMaterial)
                RoundedRectangle(cornerRadius:16).fill(world.accentColor.opacity(0.04))
                RoundedRectangle(cornerRadius:16).stroke(world.accentColor.opacity(0.22),lineWidth:1)
            })
            .shadow(color:world.accentColor.opacity(0.15),radius:12,y:4)
        }
        .buttonStyle(ScrollPressStyle())
        .offset(x: appeared ? 0 : -30).opacity(appeared ? 1 : 0)
        .onAppear { withAnimation(.easeOut(duration:0.45).delay(delay)) { appeared = true } }
    }
}

struct ScrollPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.easeOut(duration:0.12), value: configuration.isPressed)
    }
}

struct RoundedCornerShape: Shape {
    var corners: UIRectCorner; var radius: CGFloat
    func path(in rect: CGRect) -> Path {
        Path(UIBezierPath(roundedRect:rect,byRoundingCorners:corners,
                          cornerRadii:CGSize(width:radius,height:radius)).cgPath)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ConceptDetailView  — pushed by NavigationLink from world cards
// ─────────────────────────────────────────────────────────────────────────────

struct ConceptDetailView: View {
    let world: WorldInfo
    var onStartGame: (() -> Void)? = nil

    @Environment(\.dismiss) var dismiss
    @State private var info: Concept?
    @State private var navigateToGame = false

    var body: some View {
        ZStack(alignment: .topLeading) {
            LinearGradient(colors:[LDS.bg0,LDS.bg1],startPoint:.top,endPoint:.bottom).ignoresSafeArea()

            if let info {
                ScrollView(showsIndicators:false) {
                    VStack(spacing:0) {
                        Color.clear.frame(height:56)

                        ZStack(alignment:.bottom) {
                            LinearGradient(colors:[world.accentColor.opacity(0.25),.clear],startPoint:.top,endPoint:.bottom)
                                .frame(height:200)
                            VStack(spacing:8) {
                                Text(world.icon).font(.system(size:68))
                                Text(world.title)
                                    .font(.custom(LDS.bold,size:28))
                                    .foregroundStyle(LinearGradient(colors:[world.accentColor,.white],startPoint:.leading,endPoint:.trailing))
                                Text("World \(world.number)  •  Levels \(world.levels.lowerBound)–\(world.levels.upperBound)")
                                    .font(.custom(LDS.font,size:13)).foregroundColor(.white.opacity(0.45))
                            }.padding(.bottom,20)
                        }

                        VStack(spacing:14) {
                            InfoCard2(title:"What is it?",        content:info.description,         accent:world.accentColor)
                            InfoCard2(title:"How it works",       content:info.detailedExplanation, accent:world.accentColor)
                            StrategyCard(concept:world.concept,   accent:world.accentColor)
                            InfoCard2(title:"Real-world example", content:info.realWorldExample,    accent:world.accentColor)

                            NavigationLink(destination:GameView(startConcept:world.concept),isActive:$navigateToGame) { EmptyView() }

                            Button { onStartGame?(); navigateToGame=true } label: {
                                HStack(spacing:12) {
                                    Image(systemName:"play.fill").font(.system(size:16,weight:.bold))
                                    Text("Start Playing — \(world.title)").font(.custom(LDS.bold,size:16))
                                }
                                .foregroundColor(.black).frame(maxWidth:.infinity).padding(.vertical,18)
                                .background(RoundedRectangle(cornerRadius:18)
                                    .fill(LinearGradient(colors:[world.accentColor,world.accentColor.opacity(0.7)],startPoint:.topLeading,endPoint:.bottomTrailing))
                                    .shadow(color:world.accentColor.opacity(0.5),radius:18,y:6))
                            }.buttonStyle(PlainButtonStyle()).padding(.top,6)
                        }
                        .padding(.horizontal,18).padding(.bottom,100)
                    }
                }
            } else {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint:LDS.cyan))
                    .scaleEffect(1.4).frame(maxWidth:.infinity,maxHeight:.infinity)
            }

            // Back button
            Button { dismiss() } label: {
                HStack(spacing:5) {
                    Image(systemName:"chevron.left").font(.system(size:13,weight:.semibold))
                    Text("Back").font(.custom(LDS.font,size:15))
                }
                .foregroundColor(LDS.cyan).padding(.horizontal,16).padding(.vertical,10)
            }
            .padding(.top,8).padding(.leading,4)
        }
        .toolbar(.hidden, for: .navigationBar)
        .task { info = await MainActor.run { ConceptLibrary.shared.getConcept(for: world.concept) } }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// InfoCard2 / StrategyCard
// ─────────────────────────────────────────────────────────────────────────────

struct InfoCard2: View {
    let title: String; let content: String; let accent: Color
    var body: some View {
        VStack(alignment:.leading,spacing:10) {
            HStack(spacing:8) {
                Rectangle().fill(accent).frame(width:3,height:16).cornerRadius(2)
                Text(title).font(.custom(LDS.bold,size:15)).foregroundColor(accent)
            }
            Text(content).font(.custom(LDS.font,size:14)).foregroundColor(.white.opacity(0.85)).lineSpacing(4)
        }
        .padding(16).frame(maxWidth:.infinity,alignment:.leading)
        .background(RoundedRectangle(cornerRadius:14).fill(.ultraThinMaterial)
            .overlay(RoundedRectangle(cornerRadius:14).stroke(accent.opacity(0.18),lineWidth:1)))
    }
}

struct StrategyCard: View {
    let concept: PhysicsConcept; let accent: Color
    private var steps: [(Int,String)] {
        switch concept {
        case .wavePropagation: return [(1,"Tap anywhere to create a circular wave"),(2,"Wave pushes flower outward from tap point"),(3,"Tap faster for stronger force — up to ×2.0")]
        case .reflection:      return [(1,"Waves bounce off walls at equal angles"),(2,"Aim taps so reflections redirect the flower"),(3,"Experiment with angle and distance")]
        case .interference:    return [(1,"Create multiple overlapping wave fronts"),(2,"Overlapping waves multiply their force"),(3,"Time taps for constructive interference")]
        case .refraction:      return [(1,"Shallow zone (top) slows waves to ×0.6"),(2,"Deep zone (bottom) speeds waves to ×1.2"),(3,"Use zones to steer the flower's path")]
        case .resonance:       return [(1,"Create waves with consistent rhythm"),(2,"3+ active waves give 1.5× force bonus"),(3,"Find the resonant frequency for max power")]
        case .complexSystems:  return [(1,"All physics concepts are active at once"),(2,"Combine walls, zones, and timing"),(3,"Plan your multi-step strategy carefully")]
        }
    }
    var body: some View {
        VStack(alignment:.leading,spacing:12) {
            HStack(spacing:8) {
                Rectangle().fill(accent).frame(width:3,height:16).cornerRadius(2)
                Text("Gameplay Strategy").font(.custom(LDS.bold,size:15)).foregroundColor(accent)
            }
            ForEach(steps,id:\.0) { n,text in
                HStack(alignment:.top,spacing:12) {
                    ZStack {
                        Circle().fill(accent.opacity(0.18)).frame(width:26,height:26)
                        Text("\(n)").font(.custom(LDS.bold,size:12)).foregroundColor(accent)
                    }
                    Text(text).font(.custom(LDS.font,size:14)).foregroundColor(.white.opacity(0.85)).lineSpacing(3)
                    Spacer()
                }
            }
        }
        .padding(16).frame(maxWidth:.infinity,alignment:.leading)
        .background(RoundedRectangle(cornerRadius:14).fill(.ultraThinMaterial)
            .overlay(RoundedRectangle(cornerRadius:14).stroke(accent.opacity(0.18),lineWidth:1)))
    }
}

// Backward-compat aliases
typealias InfoCard = InfoCard2
typealias GuideStep = EmptyView
struct ConceptTapGuide: View { let concept: PhysicsConcept; var body: some View { EmptyView() } }

#Preview {
    NavigationStack {
        LevelsTabView()
    }
    .environmentObject(AppState())
    .preferredColorScheme(.dark)
}
