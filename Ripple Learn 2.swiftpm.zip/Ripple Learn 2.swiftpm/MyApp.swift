import SwiftUI

@main
struct RippleLearnApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
