import SwiftUI

// ─────────────────────────────────────────────────────────────────────────────
// ContentView.swift  —  Root view: drives the 3-tab experience via AppState
//
// AppState.selectedTab controls which full-screen view is shown:
//   0 → MenuView      (Home)   — owns its own NavigationStack
//   1 → Levels                 — WorldSelectionGuide in a NavigationStack
//   2 → Progress               — ProgressDashboardView
//
// LiquidTabBar lives *inside* each tab screen (via .safeAreaInset) so it
// always reads AppState from the environment and switches tabs correctly.
// ─────────────────────────────────────────────────────────────────────────────

@MainActor
final class AppState: ObservableObject {
    @Published var selectedTab: Int = 0
}

struct ContentView: View {
    @StateObject private var appState = AppState()

    var body: some View {
        ZStack(alignment: .bottom) {

            // ── Active tab content fills the whole screen ───────────────
            Group {
                switch appState.selectedTab {
                case 0:
                    HomeTabView()
                        .transition(.opacity)
                case 1:
                    NavigationStack {
                        ConceptsView()
                    }
                    .transition(.opacity)
                case 2:
                    NavigationStack {
                        ProgressDashboardView()
                            .toolbar(.hidden, for: .navigationBar)
                    }
                    .transition(.opacity)
                default:
                    HomeTabView()
                        .transition(.opacity)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .animation(.easeInOut(duration: 0.20), value: appState.selectedTab)

            // ── Pill tab bar floats at bottom center ────────────────────
            LiquidTabBar()
                .padding(.bottom, 28)
        }
        .ignoresSafeArea(edges: .bottom)
        .environmentObject(appState)
    }
}

#Preview {
    ContentView()
        .preferredColorScheme(.dark)
}
